/**
 * PLMS Phase 8.3 REV3.2.2 — C01 Independent Verification Test Runner
 *
 * Runs T01–T07 in real Chrome via CDP (Chrome DevTools Protocol).
 * Uses only Node.js standard library — zero npm dependencies.
 *
 * Usage (from workspace root):
 *   node C01-INDEPENDENT-VERIFICATION-EVIDENCE/tests/runner/run_verification.mjs
 *
 * Outputs:
 *   results/test-results.json             — full machine-readable results
 *   results/data-before-after.json        — per-test before/after store counts
 *   results/event-timelines.json          — T05/T06 event timelines
 *   results/write-operations-trace.json   — write-operation instrumentation log
 *   results/product-142-audit-report.json — field-by-field 142-product audit
 *   results/full-record-equality.json     — deep recursive record equality reports
 *   execution/cdp-console-log.txt         — Chrome console messages captured via CDP
 *   execution/execution-log.txt           — runner execution log with timestamps
 */

import http from 'http';
import fs   from 'fs';
import path from 'path';
import os   from 'os';
import { spawn } from 'child_process';
import { fileURLToPath } from 'url';
import { createHash } from 'crypto';

const __filename = fileURLToPath(import.meta.url);
const __dirname  = path.dirname(__filename);
const EVIDENCE_DIR = path.resolve(__dirname, '..', '..');
const WORK_DIR     = path.resolve(EVIDENCE_DIR, '..'); // workspace root

const HTTP_PORT  = 49901;
const CDP_PORT   = 49902;
const USER_DATA  = path.join(os.tmpdir(), 'chrome_c01_iv_' + Date.now());

const CHROME_PATHS = [
  'C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe',
  'C:\\Program Files (x86)\\Google\\Chrome\\Application\\chrome.exe',
  (process.env.LOCALAPPDATA || '') + '\\Google\\Chrome\\Application\\chrome.exe'
];
const CHROME = CHROME_PATHS.find(p => p && fs.existsSync(p));
if (!CHROME) { console.error('[FATAL] Chrome executable not found'); process.exit(1); }

const MIME = {
  '.html': 'text/html; charset=utf-8',
  '.js':   'application/javascript; charset=utf-8',
  '.json': 'application/json; charset=utf-8'
};

// ── Execution log ────────────────────────────────────────────────────────────
const execLog = [];
function log(msg) {
  const line = `[${new Date().toISOString()}] ${msg}`;
  execLog.push(line);
  console.log(line);
}

// ── HTTP server ──────────────────────────────────────────────────────────────
function startServer() {
  return new Promise((resolve, reject) => {
    const srv = http.createServer((req, res) => {
      let p = req.url.split('?')[0];
      if (p === '/' || p === '')
        p = '/C01-INDEPENDENT-VERIFICATION-EVIDENCE/tests/harness/c01_verification_harness.html';
      const fp = path.join(WORK_DIR, p);
      if (!fs.existsSync(fp) || fs.statSync(fp).isDirectory()) {
        res.writeHead(404); res.end('Not Found: ' + p); return;
      }
      const ext = path.extname(fp).toLowerCase();
      res.writeHead(200, {
        'Content-Type': MIME[ext] || 'application/octet-stream',
        'Cache-Control': 'no-cache'
      });
      fs.createReadStream(fp).pipe(res);
    });
    srv.listen(HTTP_PORT, '127.0.0.1', () => resolve(srv));
    srv.on('error', reject);
  });
}

function sleep(ms) { return new Promise(r => setTimeout(r, ms)); }

async function fetchJson(url) {
  return new Promise((resolve, reject) => {
    http.get(url, res => {
      let d = '';
      res.on('data', c => d += c);
      res.on('end', () => { try { resolve(JSON.parse(d)); } catch(e) { reject(e); } });
    }).on('error', reject);
  });
}

async function connectWS(url, timeout = 20000) {
  return new Promise((resolve, reject) => {
    const timer = setTimeout(() => reject(new Error('WS connect timeout: ' + url)), timeout);
    const ws = new globalThis.WebSocket(url);
    ws.onopen  = () => { clearTimeout(timer); resolve(ws); };
    ws.onerror = (e) => { clearTimeout(timer); reject(new Error('WS error: ' + String(e))); };
  });
}

function cdpClient(ws) {
  let id = 1;
  const cdpConsole = [];
  ws.addEventListener('message', (evt) => {
    try {
      const msg = JSON.parse(evt.data);
      if (msg.method === 'Runtime.consoleAPICalled') {
        const text = msg.params.args.map(a => a.value ?? a.description ?? '').join(' ');
        cdpConsole.push({ type: msg.params.type, text, timestamp: msg.params.timestamp });
      }
      if (msg.method === 'Runtime.exceptionThrown') {
        const desc = msg.params.exceptionDetails?.exception?.description || msg.params.exceptionDetails?.text || 'Uncaught error';
        cdpConsole.push({ type: 'uncaught_exception', text: desc, timestamp: Date.now() });
        console.error('[Browser Uncaught Exception]', desc);
      }
    } catch (_) {}
  });
  return {
    cdpConsole,
    send(method, params = {}, timeoutMs = 60000) {
      return new Promise((resolve, reject) => {
        const myId = id++;
        const timer = setTimeout(() => {
          ws.removeEventListener('message', handler);
          reject(new Error(`CDP timeout (${timeoutMs}ms): ${method}`));
        }, timeoutMs);
        const handler = (evt) => {
          const r = JSON.parse(evt.data);
          if (r.id === myId) {
            clearTimeout(timer);
            ws.removeEventListener('message', handler);
            if (r.error) reject(new Error(`CDP ${method}: ${r.error.message}`));
            else resolve(r.result);
          }
        };
        ws.addEventListener('message', handler);
        ws.send(JSON.stringify({ id: myId, method, params }));
      });
    },
    async eval(expr, timeoutMs = 90000) {
      const r = await this.send('Runtime.evaluate', {
        expression: expr, returnByValue: true, awaitPromise: true
      }, timeoutMs);
      if (r.exceptionDetails)
        throw new Error('JS exception: ' + (r.exceptionDetails.text || JSON.stringify(r.exceptionDetails)));
      return r.result?.value;
    }
  };
}

// ── Hash verification ────────────────────────────────────────────────────────
function sha256File(filePath) {
  const data = fs.readFileSync(filePath);
  return createHash('sha256').update(data).digest('hex').toUpperCase();
}

// ── Main ─────────────────────────────────────────────────────────────────────
async function main() {
  const runStart = new Date().toISOString();
  log(`Runner started at ${runStart}`);
  log(`Evidence dir: ${EVIDENCE_DIR}`);
  log(`Workspace dir: ${WORK_DIR}`);

  // --- Verify source hash before running ---
  const srcPath = path.join(WORK_DIR, 'src', 'PatriaLactis.jsx');
  const compiledPath = path.join(EVIDENCE_DIR, 'compiled', 'appLogic.js');
  const srcHash = sha256File(srcPath);
  const compiledHash = sha256File(compiledPath);
  const EXPECTED_SRC_HASH = '5DA61F1021C99FAC1834A6A45AF067D784F4897B244EAE362DA6597779B2D63D';
  const EXPECTED_COMPILED_HASH = '9AB9A4B0E70FCD77D88014606F8B0EC335C90DAA3E19FBDFAE6C0D419BF65C62';

  log(`PatriaLactis.jsx SHA-256: ${srcHash}`);
  log(`appLogic.js SHA-256:      ${compiledHash}`);

  if (srcHash !== EXPECTED_SRC_HASH) {
    log(`[FATAL] Source hash mismatch! Expected ${EXPECTED_SRC_HASH}, got ${srcHash}`);
    log(`[FATAL] Tests will NOT run on a different source version. Stopping.`);
    process.exit(2);
  }
  log(`[OK] Source hash verified.`);
  if (compiledHash !== EXPECTED_COMPILED_HASH) {
    log(`[WARN] Compiled hash mismatch — recompile before running tests.`);
  } else {
    log(`[OK] Compiled hash verified.`);
  }

  const server = await startServer();
  log(`HTTP server listening on port ${HTTP_PORT}`);
  fs.mkdirSync(USER_DATA, { recursive: true });

  const harnesURL = `http://127.0.0.1:${HTTP_PORT}/C01-INDEPENDENT-VERIFICATION-EVIDENCE/tests/harness/c01_verification_harness.html`;
  log(`Launching Chrome: ${CHROME}`);
  log(`Test harness URL: ${harnesURL}`);

  const chrome = spawn(CHROME, [
    `--remote-debugging-port=${CDP_PORT}`,
    `--user-data-dir=${USER_DATA}`,
    '--no-first-run', '--no-default-browser-check', '--disable-extensions',
    '--headless=new',
    harnesURL
  ], { stdio: 'ignore' });

  let ws, client;
  try {
    // Connect to CDP
    for (let i = 0; i < 40; i++) {
      await sleep(500);
      try {
        const targets = await fetchJson(`http://127.0.0.1:${CDP_PORT}/json`);
        const page = targets.find(t => t.type === 'page');
        if (page) { ws = await connectWS(page.webSocketDebuggerUrl); break; }
      } catch (_) {}
    }
    if (!ws) throw new Error('Could not connect to Chrome CDP after 20s');
    client = cdpClient(ws);
    await client.send('Runtime.enable');
    await client.send('Console.enable');
    log(`CDP connected. Waiting for T01–T07 to complete...`);

    // Poll for completion (max 120s)
    let done = false;
    for (let i = 0; i < 240; i++) {
      await sleep(500);
      try { done = await client.eval('Boolean(window.__TESTS_DONE__)'); if (done) break; }
      catch (_) {}
    }
    if (!done) throw new Error('Test suite timed out after 120s');
    log(`Tests complete. Collecting results...`);

    const rawJson = await client.eval('JSON.stringify(window.__TEST_RESULTS__)');
    const data = JSON.parse(rawJson);
    const runEnd = new Date().toISOString();

    // --- Write results ---
    const resultsDir  = path.join(EVIDENCE_DIR, 'results');
    const execDir     = path.join(EVIDENCE_DIR, 'execution');
    fs.mkdirSync(resultsDir, { recursive: true });
    fs.mkdirSync(execDir,    { recursive: true });

    // 1. Full results JSON
    fs.writeFileSync(path.join(resultsDir, 'test-results.json'),
      JSON.stringify(data, null, 2), 'utf8');

    // 2. Before/after data
    const beforeAfter = data.results.map(r => ({
      testId: r.testId, dbName: r.dbName || null,
      before: r.beforeCounts, after: r.afterCounts,
      clearHappened: r.clearHappened, pass: r.pass
    }));
    fs.writeFileSync(path.join(resultsDir, 'data-before-after.json'),
      JSON.stringify(beforeAfter, null, 2), 'utf8');

    // 3. Event timelines (T05 injection log, T06 timeline)
    const timelines = {};
    for (const r of data.results) {
      if (r.injectionLog) timelines[r.testId + '_injectionLog'] = r.injectionLog;
      if (r.timeline)     timelines[r.testId + '_timeline']     = r.timeline;
      if (r.proofDetails) timelines[r.testId + '_proofDetails'] = r.proofDetails;
    }
    fs.writeFileSync(path.join(resultsDir, 'event-timelines.json'),
      JSON.stringify(timelines, null, 2), 'utf8');

    // 4. Write operations trace
    const writeTrace = {
      globalWriteLog: data.globalWriteLog || [],
      perTestWrites: data.results.map(r => ({
        testId: r.testId,
        dispatchedCount: r.writeOperations ? r.writeOperations.length : 0,
        writes: r.writeOperations || [],
        summary: r.writeOperationsSummary || null
      }))
    };
    fs.writeFileSync(path.join(resultsDir, 'write-operations-trace.json'),
      JSON.stringify(writeTrace, null, 2), 'utf8');

    // 5. Product 142 audit report (from T04)
    const t04 = data.results.find(r => r.testId === 'T04');
    if (t04 && t04.productAuditReport) {
      fs.writeFileSync(path.join(resultsDir, 'product-142-audit-report.json'),
        JSON.stringify(t04.productAuditReport, null, 2), 'utf8');
    }

    // 6. Full record equality report
    const equalityReports = data.results
      .filter(r => r.fullRecordEquality)
      .map(r => ({
        testId: r.testId,
        verified: r.fullRecordEquality.verified,
        details: r.fullRecordEquality
      }));
    fs.writeFileSync(path.join(resultsDir, 'full-record-equality.json'),
      JSON.stringify(equalityReports, null, 2), 'utf8');

    // 7. CDP console log
    const cdpLines = client.cdpConsole
      .map(e => `[${e.type.toUpperCase()}] ${e.text}`)
      .join('\n');
    fs.writeFileSync(path.join(execDir, 'cdp-console-log.txt'),
      cdpLines, 'utf8');

    // 8. Execution log
    log(`Run ended at ${runEnd}`);
    log(`Overall: ${data.overallPass ? 'ALL PASS ✅' : 'FAILURES DETECTED ❌'}`);
    fs.writeFileSync(path.join(execDir, 'execution-log.txt'),
      execLog.join('\n'), 'utf8');

    // Print summary
    console.log('\n╔════════════════════════════════════════════════════════════════════════╗');
    console.log('║  PLMS REV3.2.2 — C01 Hardened Verification Results (T01–T07)          ║');
    console.log('╠════════════════════════════════════════════════════════════════════════╣');
    for (const r of data.results) {
      const icon = r.pass ? 'PASS ✅' : 'FAIL ❌';
      console.log(`║  [${icon}] ${r.testId}: ${(r.description || '').substring(0, 56).padEnd(56)}`);
      if (r.beforeCounts !== undefined) {
        const bc = r.beforeCounts; const ac = r.afterCounts;
        console.log(`║    DB: ${(r.dbName||'').substring(0,60)}`);
        console.log(`║    products: ${bc?.products}→${ac?.products}  clearHappened=${r.clearHappened}`);
      }
      if (r.fullRecordEquality) {
        console.log(`║    Full Record Equality: ${r.fullRecordEquality.verified ? 'VERIFIED ✅' : 'FAILED ❌'}`);
      }
      if (r.productAuditReport) {
        console.log(`║    142-Product Audit: ${r.productAuditReport.matchCount}/142 matched (discrepancies: ${r.productAuditReport.discrepancyCount})`);
      }
      if (r.writeOperationsSummary) {
        console.log(`║    Writes Policy Compliant: ${r.writeOperationsSummary.policyCompliant ? 'YES ✅' : 'NO ❌'} (adds: ${r.writeOperationsSummary.productsAdd}, clear: ${r.writeOperationsSummary.productsClear}, puts: ${r.writeOperationsSummary.settingsPut})`);
      }
      if (r.assertions) {
        for (const [k, v] of Object.entries(r.assertions)) {
          console.log(`║      assertion "${k.substring(0,46)}": ${v ? 'PASS' : 'FAIL'}`);
        }
      }
    }
    console.log('╠════════════════════════════════════════════════════════════════════════╣');
    console.log(`║  OVERALL: ${data.overallPass ? 'ALL TESTS PASSED ✅' : 'FAILURES DETECTED ❌'}`.padEnd(72) + '║');
    console.log('╚════════════════════════════════════════════════════════════════════════╝\n');

  } finally {
    try { ws?.close(); }  catch (_) {}
    try { chrome.kill(); } catch (_) {}
    try { server.close(); } catch (_) {}
    try {
      if (fs.existsSync(USER_DATA))
        fs.rmSync(USER_DATA, { recursive: true, force: true });
    } catch (_) {}
  }
}

main().catch(err => {
  log(`[FATAL] Runner unhandled: ${err}`);
  console.error(err);
  process.exit(1);
});
