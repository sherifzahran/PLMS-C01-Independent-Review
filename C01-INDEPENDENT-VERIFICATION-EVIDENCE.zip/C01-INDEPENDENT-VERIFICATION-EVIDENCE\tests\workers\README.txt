WORKER FILES NOTE
In this test architecture, testing executes in the main DOM thread of the headless Chrome browser tab
driven via Chrome DevTools Protocol (CDP), with asynchronous Web Workers not required for single-tab
IndexedDB transactions. Concurrency multi-connection tests (Finding B) use two separate browser tabs
connected to the same origin, managed directly by the runner.
