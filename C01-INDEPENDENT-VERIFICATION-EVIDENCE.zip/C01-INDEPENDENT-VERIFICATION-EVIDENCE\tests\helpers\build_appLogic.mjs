import fs from "fs";

const content = fs.readFileSync("D:/Patria lacts Project/PLMS-PRODUCTION/PLMS-PHASE8.3-REV3.2.2-REMEDIATION/src/PatriaLactis.jsx", "utf8");

const seedStart = content.indexOf("const SEED_PRODUCTS = [");
const seedEnd = content.indexOf("];", seedStart) + 2;
const seedCode = content.slice(seedStart, seedEnd);

const catStart = content.indexOf("async function initProductionCatalog()");
const catEnd = content.indexOf("// ══════════════════════════════════════════════", catStart);
const catCode = content.slice(catStart, catEnd);

const prStart = content.indexOf("async function performRestore(backup)");
const prEnd = content.indexOf("function BackupScreen", prStart);
const prCode = content.slice(prStart, prEnd);

const openStart = content.indexOf("async function open()");
const returnIdx = content.indexOf("return (", openStart);
const openCode = content.slice(openStart, returnIdx);

const helperStart = content.indexOf("function isValidCalendarDate(dateStr)");
const helperEnd = content.indexOf("async function performRestore");
const helperCode = content.slice(helperStart, helperEnd);

const moduleCode = `// Generated appLogic.js for browser testing
import {
  restoreFromVerifiedBackup,
  verifyBackupPayload,
  computeSha256,
  runPostUpdateVerification,
  EXPECTED_STORES,
  BACKUP_FORMAT_VERSION,
  SCHEMA_VERSION,
  DB_VERSION,
  PROTECTED_SECURITY_FIELDS,
  validateRelationalIntegrity
} from "./safeUpdate.js";

export {
  EXPECTED_STORES,
  BACKUP_FORMAT_VERSION,
  SCHEMA_VERSION,
  DB_VERSION,
  PROTECTED_SECURITY_FIELDS,
  validateRelationalIntegrity
};

export let currentDB = null;
export function setDB(db) { currentDB = db; }
export async function openDB() { return currentDB; }

export const auditLogs = [];
export async function writeAuditLog(action, details) {
  auditLogs.push({ timestamp: Date.now(), action, details });
}

export async function getSettings() {
  const db = await openDB();
  return new Promise((resolve) => {
    try {
      const req = db.transaction("settings", "readonly").objectStore("settings").get("app");
      req.onsuccess = () => resolve(req.result ? (req.result.value || req.result) : null);
      req.onerror = () => resolve(null);
    } catch (_) { resolve(null); }
  });
}

${seedCode}

${catCode}

${helperCode}

${prCode}

export { performRestore, isValidCalendarDate, initProductionCatalog, SEED_PRODUCTS };

export async function executeOpen(db, date, { onToast = () => {}, onDayOpened = () => {} } = {}) {
  let opening = false;
  const setOpening = (val) => { opening = val; };
  currentDB = db;

  ${openCode}

  await open();
}
`;

fs.writeFileSync("D:/Patria lacts Project/PLMS-PRODUCTION/PLMS-PHASE8.3-REV3.2.2-REMEDIATION/scratch/compiled/appLogic.js", moduleCode, "utf8");
console.log("appLogic.js compiled successfully with atomic initProductionCatalog for REV3.2.2.");
