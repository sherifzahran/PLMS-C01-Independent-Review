/**
 * PLMS Phase 6: Safe Update, Backup & Recovery System — HARDENED
 *
 * Strict Golden Rule: NO VERIFIED BACKUP = NO UPDATE
 *
 * Hardening changes vs baseline:
 *   1. Recovery backup storage: IDB settings store → Cache Storage (independent of IDB)
 *   2. Backup verification: uses live IDB counts, NOT backup.recordCounts
 *   3. Audit events: all 10 events now have real dbAdd() writes
 *   4. Recovery detection: localStorage-only (no IDB dependency)
 *   5. OPFS tested at runtime; Cache Storage selected as primary (broader browser support)
 *
 * Strictly preserves:
 * - Exactly 13 IndexedDB stores
 * - DB_VERSION = 2, SCHEMA_VERSION = "1.3.0", APP_VERSION = "1.1.0"
 * - No `sales` store
 * - All historical calculations, calcDay(), Sales Return, Closing Stock
 */

export const DB_NAME = "PatriaLactisDB";
export const DB_VERSION = 2;
export const SCHEMA_VERSION = "1.3.0";
export const APP_VERSION = "1.1.0";
export const BACKUP_FORMAT_VERSION = "PLMS-BACKUP-v2.0";
export const MAX_RECOVERY_BACKUPS = 3;

// Recovery storage uses Cache Storage (independent of IDB)
// Hardened in Phase 8.3: Uses valid origin-relative paths supported by W3C Cache Storage API across all browsers
const RECOVERY_CACHE_NAME = "plms-recovery-v1";
const RECOVERY_INDEX_URL = "/plms-cache/recovery/index.json";
const RECOVERY_BACKUP_URL_PREFIX = "/plms-cache/recovery/backup/";
// Legacy URLs supported for non-destructive read migration if present in existing stores
const LEGACY_RECOVERY_INDEX_URL = "plms://recovery/index.json";
const LEGACY_RECOVERY_BACKUP_URL_PREFIX = "plms://recovery/backup/";

export const EXPECTED_STORES = [
  "products",
  "days",
  "dayReopenLogs",
  "openingStock",
  "loads",
  "additions",
  "unloads",
  "damages",
  "discounts",
  "closingStock",
  "dayPriceSnapshot",
  "auditLog",
  "settings"
] as const;

export const PROTECTED_SECURITY_FIELDS = [
  "managerPasswordHash",
  "userPinHash",
  "trustedManagerPublicKey",
  "secretKey"
] as const;

/**
 * R-02 / SEC-03: Documented allowlist of local settings keys that are permitted
 * to be preserved on the local device during backup restoration even when absent
 * from the incoming backup payload. All other local keys not present in the backup
 * are treated as stale and must be cleanly purged.
 */
export const LOCAL_SETTINGS_PRESERVE_ALLOWLIST = [
  ...PROTECTED_SECURITY_FIELDS
] as const;

export type StoreName = (typeof EXPECTED_STORES)[number];

export type UpdateStateStatus =
  | "idle"
  | "update_detected"
  | "precheck_running"
  | "precheck_passed"
  | "backup_creating"
  | "backup_created"
  | "backup_verifying"
  | "backup_verified"
  | "migration_running"
  | "migration_completed"
  | "post_verify_running"
  | "post_verify_passed"
  | "completed"
  | "failed"
  | "recovery_required";

export interface BackupIntegrity {
  algorithm: "SHA-256";
  checksum: string;
  totalRecords: number;
}

export interface BackupMetadata {
  backupFormat: string;
  appVersion: string;
  schemaVersion: string;
  databaseVersion: number;
  exportDate: string;
  exportedAt: number;
  exportedBy: string;
  driverName: string;
  carNumber: string;
  deviceInfo?: Record<string, any>;
  recordCounts: Record<string, number>;
  integrity: BackupIntegrity;
}

export interface CompleteBackupPayload extends BackupMetadata {
  data: Record<string, any[]>;
}

export interface RecoveryIndexEntry {
  id: string;
  key: string;
  timestamp: number;
  exportDate: string;
  driverName: string;
  carNumber: string;
  totalRecords: number;
  checksum: string;
  appVersion: string;
  schemaVersion: string;
  databaseVersion: number;
}

export interface UpdateTransaction {
  id: string;
  status: UpdateStateStatus;
  startedAt: number;
  updatedAt: number;
  targetVersion?: {
    appVersion: string;
    schemaVersion: string;
    dbVersion: number;
  };
  recoveryBackupKey?: string;
  lastError?: string;
  stepDescription?: string;
}

export interface PreUpdateSafetyCheckResult {
  passed: boolean;
  error?: string;
  details: {
    dbAccessible: boolean;
    storesExist: boolean;
    storeCount: number;
    dbVersion: number;
    schemaVersion: string;
    appVersion: string;
    quotaAvailable?: boolean;
    quotaEstimate?: { quota?: number; usage?: number };
    noCriticalConflict: boolean;
  };
}

export interface BackupVerificationResult {
  valid: boolean;
  error?: string;
  checksum: string;
  countsMatch: boolean;
  storeCounts: Record<string, number>;
  totalRecords: number;
}

export interface PostUpdateVerificationResult {
  passed: boolean;
  error?: string;
  details: {
    dbOpened: boolean;
    storesCount: number;
    storesMatch: boolean;
    dbVersionMatch: boolean;
    schemaVersionMatch: boolean;
    recordsAccessible: boolean;
    settingsAccessible: boolean;
    noSalesStore: boolean;
    recordCountsMatch?: boolean;
  };
}

export interface RecoveryStorageTestResult {
  cacheStorageAvailable: boolean;
  opfsAvailable: boolean;
  opfsStatus: string;
  selectedStorage: "cache" | "opfs" | "none";
  testWriteSuccess: boolean;
  testReadSuccess: boolean;
  testPersistenceVerified: boolean;
  error?: string;
}

const LOCAL_STORAGE_TX_KEY = "plms_update_transaction";

// ── SHA-256 CHECKSUM ──────────────────────────────────────────────

export async function computeSha256(text: string): Promise<string> {
  if (typeof crypto !== "undefined" && crypto.subtle) {
    const encoder = new TextEncoder();
    const data = encoder.encode(text);
    const hashBuffer = await crypto.subtle.digest("SHA-256", data);
    const hashArray = Array.from(new Uint8Array(hashBuffer));
    return hashArray.map((b) => b.toString(16).padStart(2, "0")).join("");
  }
  // Deterministic fallback for environments without subtle crypto
  let hash = 0;
  for (let i = 0; i < text.length; i++) {
    const char = text.charCodeAt(i);
    hash = (hash << 5) - hash + char;
    hash = hash & hash;
  }
  return "hash_" + Math.abs(hash).toString(16);
}

// ── TRANSACTION STATE HANDLING ────────────────────────────────────

export function getUpdateTransaction(): UpdateTransaction | null {
  try {
    if (typeof localStorage === "undefined") return null;
    const raw = localStorage.getItem(LOCAL_STORAGE_TX_KEY);
    if (!raw) return null;
    return JSON.parse(raw);
  } catch {
    return null;
  }
}

export function setUpdateTransaction(tx: UpdateTransaction | null): void {
  try {
    if (typeof localStorage === "undefined") return;
    if (!tx || tx.status === "idle") {
      localStorage.removeItem(LOCAL_STORAGE_TX_KEY);
    } else {
      localStorage.setItem(LOCAL_STORAGE_TX_KEY, JSON.stringify(tx));
    }
  } catch (err) {
    console.warn("[SafeUpdate] Failed to write transaction to localStorage:", err);
  }
}

// detectInterruptedUpdate() uses ONLY localStorage — no IDB dependency
export function detectInterruptedUpdate(): {
  interrupted: boolean;
  transaction: UpdateTransaction | null;
  message?: string;
} {
  const tx = getUpdateTransaction();
  if (!tx) return { interrupted: false, transaction: null };

  const incompleteStatuses: UpdateStateStatus[] = [
    "backup_creating",
    "backup_created",
    "backup_verifying",
    "backup_verified",
    "migration_running",
    "migration_completed",
    "post_verify_running",
    "recovery_required",
    "failed"
  ];

  if (incompleteStatuses.includes(tx.status)) {
    return {
      interrupted: true,
      transaction: tx,
      message: "تم اكتشاف تحديث غير مكتمل. التطبيق في وضع الاسترداد الآمن."
    };
  }

  return { interrupted: false, transaction: tx };
}

// ── STARTUP SEQUENCE (BLOCKER #1 FIX) ─────────────────────────────
//
// Recovery detection MUST happen BEFORE opening IndexedDB.
// If an interrupted update is detected from localStorage, the app
// immediately enters Recovery Mode without attempting to open IndexedDB.
// This prevents IndexedDB open failures/hangs from blocking recovery.

export interface AppStartupWorkflowResult {
  mode: "recovery" | "normal" | "db_error";
  interruptedState?: {
    interrupted: boolean;
    transaction: UpdateTransaction | null;
    message?: string;
  };
  db?: IDBDatabase;
  error?: string;
}

export async function executeStartupSequence(
  openDbFn: () => Promise<IDBDatabase>
): Promise<AppStartupWorkflowResult> {
  // Step 1: Detect interrupted update purely from localStorage (NO IDB DEPENDENCY)
  const interrupted = detectInterruptedUpdate();
  if (interrupted.interrupted) {
    return {
      mode: "recovery",
      interruptedState: interrupted
    };
  }

  // Step 2: Normal startup — open IndexedDB only after verifying no recovery is needed
  try {
    const db = await openDbFn();
    return {
      mode: "normal",
      db
    };
  } catch (err: any) {
    const errMsg = err?.message || String(err);
    return {
      mode: "db_error",
      error: errMsg,
      interruptedState: {
        interrupted: true,
        transaction: {
          id: `db_err_${Date.now()}`,
          status: "recovery_required",
          startedAt: Date.now(),
          updatedAt: Date.now(),
          lastError: `تعذر فتح قاعدة البيانات: ${errMsg}`,
          stepDescription: "خطأ أثناء تشغيل قاعدة البيانات"
        },
        message: "تعذر فتح قاعدة البيانات. التطبيق في وضع الاسترداد الآمن."
      }
    };
  }
}

// ── RECOVERY STORAGE: CACHE STORAGE (IDB-INDEPENDENT) ────────────
//
// Recovery backups are stored in the browser's Cache Storage API,
// which is completely independent of IndexedDB. This means recovery
// data remains accessible even if IDB fails to open.
//
// Storage architecture:
//   Cache name:  "plms-recovery-v1"
//   Index URL:   "plms://recovery/index.json"
//   Backup URLs: "plms://recovery/backup/<id>"

async function getCacheStorage(): Promise<Cache | null> {
  try {
    if (typeof caches === "undefined") return null;
    return await caches.open(RECOVERY_CACHE_NAME);
  } catch {
    return null;
  }
}

async function readCacheJson<T>(cache: Cache, url: string): Promise<T | null> {
  try {
    const resp = await cache.match(url);
    if (!resp) return null;
    return (await resp.json()) as T;
  } catch {
    return null;
  }
}

async function writeCacheJson(cache: Cache, url: string, data: unknown): Promise<void> {
  const body = JSON.stringify(data);
  const resp = new Response(body, {
    headers: {
      "Content-Type": "application/json",
      "X-PLMS-Storage": "recovery"
    }
  });
  await cache.put(url, resp);
}

// ── RECOVERY STORAGE TEST ─────────────────────────────────────────
//
// Tests Cache Storage availability in the actual runtime environment.
// Called once at safe-update workflow start.

export async function testRecoveryStorage(): Promise<RecoveryStorageTestResult> {
  const result: RecoveryStorageTestResult = {
    cacheStorageAvailable: false,
    opfsAvailable: false,
    opfsStatus: "not checked",
    selectedStorage: "none",
    testWriteSuccess: false,
    testReadSuccess: false,
    testPersistenceVerified: false
  };

  // Test Cache Storage (primary recovery storage mechanism)
  try {
    const testCache = await caches.open("plms-storage-test-v1");
    const testUrl = "/plms-cache/test/probe";
    const testData = { ts: Date.now(), probe: true };
    await writeCacheJson(testCache, testUrl, testData);
    const readBack = await readCacheJson<typeof testData>(testCache, testUrl);
    await caches.delete("plms-storage-test-v1");

    if (readBack && readBack.probe === true) {
      result.cacheStorageAvailable = true;
      result.selectedStorage = "cache";
      result.testWriteSuccess = true;
      result.testReadSuccess = true;
      result.testPersistenceVerified = true;
    }
  } catch (e: any) {
    result.error = `Cache Storage: ${e?.message || String(e)}`;
  }

  // Check OPFS availability only (API presence check — not tested for read/write persistence)
  try {
    if (
      typeof navigator !== "undefined" &&
      navigator.storage &&
      typeof (navigator.storage as any).getDirectory === "function"
    ) {
      result.opfsAvailable = true;
      result.opfsStatus = "availability checked only (API presence check)";
    } else {
      result.opfsStatus = "not supported in this environment";
    }
  } catch {
    result.opfsStatus = "check failed";
  }

  if (!result.cacheStorageAvailable) {
    result.selectedStorage = "none";
    result.error = (result.error || "") + " Cache Storage not available in this environment.";
  }

  return result;
}

// ── PRE-UPDATE SAFETY CHECK ───────────────────────────────────────

export async function runPreUpdateSafetyCheck(
  db: IDBDatabase,
  settings: any
): Promise<PreUpdateSafetyCheckResult> {
  const details: PreUpdateSafetyCheckResult["details"] = {
    dbAccessible: false,
    storesExist: false,
    storeCount: 0,
    dbVersion: 0,
    schemaVersion: "",
    appVersion: "",
    noCriticalConflict: true
  };

  try {
    if (!db) {
      return {
        passed: false,
        error: "قاعدة البيانات غير متاحة حالياً.",
        details
      };
    }
    details.dbAccessible = true;
    details.dbVersion = db.version;
    details.storeCount = db.objectStoreNames.length;

    // Check all 13 stores exist
    const missingStores = EXPECTED_STORES.filter(
      (s) => !db.objectStoreNames.contains(s)
    );
    if (missingStores.length > 0) {
      return {
        passed: false,
        error: `بعض جداول قاعدة البيانات مفقودة: ${missingStores.join(", ")}`,
        details
      };
    }
    details.storesExist = true;

    // Check storage quota if API available
    if (
      typeof navigator !== "undefined" &&
      navigator.storage &&
      navigator.storage.estimate
    ) {
      try {
        const est = await navigator.storage.estimate();
        details.quotaEstimate = est;
        // Require at least 20MB available if quota is reported
        if (est.quota && est.usage) {
          const remaining = est.quota - est.usage;
          details.quotaAvailable = remaining > 20 * 1024 * 1024;
          if (!details.quotaAvailable) {
            return {
              passed: false,
              error: "مساحة التخزين المتاحة في المتصفح غير كافية لإنشاء نسخة احتياطية آمنة.",
              details
            };
          }
        }
      } catch {
        details.quotaAvailable = true;
      }
    }

    // Check settings readable
    details.schemaVersion = settings?.schemaVersion || SCHEMA_VERSION;
    details.appVersion = settings?.appVersion || APP_VERSION;

    return {
      passed: true,
      details
    };
  } catch (err: any) {
    return {
      passed: false,
      error: `فشل فحص الأمان المسبق: ${err?.message || String(err)}`,
      details
    };
  }
}

// ── LIVE STORE COUNT READER ───────────────────────────────────────
//
// Reads live record counts from ALL 13 IDB stores independently.
// Used by verifyBackupPayload to validate backup against live data.

export async function readLiveStoreCounts(
  db: IDBDatabase
): Promise<Record<string, number>> {
  const counts: Record<string, number> = {};
  for (const storeName of EXPECTED_STORES) {
    counts[storeName] = await new Promise<number>((resolve, reject) => {
      try {
        const tx = db.transaction(storeName, "readonly");
        const store = tx.objectStore(storeName);
        // For settings store, mirror createMandatoryBackup filtering of transient keys
        // to prevent false-positive mismatch when update state is active (R-19)
        if (storeName === "settings" && typeof store.getAll === "function") {
          const req = store.getAll();
          req.onsuccess = () => {
            const records = req.result || [];
            const filtered = records.filter(
              (r: any) => r && r.key !== "plms_update_state"
            );
            resolve(filtered.length);
          };
          req.onerror = () => reject(req.error);
        } else {
          const req = store.count();
          req.onsuccess = () => resolve(req.result);
          req.onerror = () => reject(req.error);
        }
      } catch (e) {
        reject(e);
      }
    });
  }
  return counts;
}

// ── MANDATORY BACKUP CREATION ─────────────────────────────────────

export async function createMandatoryBackup(
  db: IDBDatabase,
  settings: any
): Promise<CompleteBackupPayload> {
  const data: Record<string, any[]> = {};
  const recordCounts: Record<string, number> = {};
  let totalRecords = 0;

  // Read all 13 stores
  for (const storeName of EXPECTED_STORES) {
    const records = await new Promise<any[]>((resolve, reject) => {
      try {
        const tx = db.transaction(storeName, "readonly");
        const store = tx.objectStore(storeName);
        const req = store.getAll();
        req.onsuccess = () => resolve(req.result || []);
        req.onerror = () => reject(req.error);
      } catch (e) {
        reject(e);
      }
    });

    // In settings store, filter out transient state keys to prevent recursion
    if (storeName === "settings") {
      const filtered = records.filter(
        (r) =>
          r.key !== "plms_update_state"
      );
      data[storeName] = filtered;
      recordCounts[storeName] = filtered.length;
      totalRecords += filtered.length;
    } else {
      data[storeName] = records;
      recordCounts[storeName] = records.length;
      totalRecords += records.length;
    }
  }

  const now = Date.now();
  const dateStr = new Date(now).toISOString();

  // Canonical serialized string for deterministic hashing
  const canonicalData = JSON.stringify(data);
  const checksum = await computeSha256(canonicalData);

  const backup: CompleteBackupPayload = {
    backupFormat: BACKUP_FORMAT_VERSION,
    appVersion: settings?.appVersion || APP_VERSION,
    schemaVersion: settings?.schemaVersion || SCHEMA_VERSION,
    databaseVersion: db.version || DB_VERSION,
    exportDate: dateStr,
    exportedAt: now,
    exportedBy: (settings?.driverName || "").trim() || "غير محدد",
    driverName: (settings?.driverName || "").trim() || "غير محدد",
    carNumber: (settings?.carNumber || "").trim() || "غير محدد",
    deviceInfo: {
      userAgent: typeof navigator !== "undefined" ? navigator.userAgent : "unknown"
    },
    recordCounts,
    integrity: {
      algorithm: "SHA-256",
      checksum,
      totalRecords
    },
    data
  };

  return backup;
}

// ── BACKUP VERIFICATION ───────────────────────────────────────────
//
// HARDENING: sourceCounts MUST be live IDB counts (from readLiveStoreCounts),
// NOT backup.recordCounts. Passing backup.recordCounts here is a circular check
// and is explicitly rejected by this function.

export async function verifyBackupPayload(
  backup: CompleteBackupPayload,
  sourceCounts?: Record<string, number>
): Promise<BackupVerificationResult> {
  const result: BackupVerificationResult = {
    valid: false,
    checksum: "",
    countsMatch: false,
    storeCounts: {},
    totalRecords: 0
  };

  try {
    if (!backup || typeof backup !== "object") {
      result.error = "هيكل النسخة الاحتياطية غير صالح.";
      return result;
    }

    if (!backup.backupFormat || typeof backup.backupFormat !== "string" || !backup.backupFormat.startsWith("PLMS-BACKUP-")) {
      result.error = "تنسيق النسخة الاحتياطية غير معروف.";
      return result;
    }

    if (!backup.data || typeof backup.data !== "object") {
      result.error = "بيانات النسخة الاحتياطية مفقودة.";
      return result;
    }

    // Verify no alien / unrecognized stores exist in backup.data (R-17-META)
    const storeKeys = Object.keys(backup.data);
    for (const key of storeKeys) {
      if (!EXPECTED_STORES.includes(key as any)) {
        result.error = `النسخة الاحتياطية تحتوي على جدول غير معروف: "${key}".`;
        return result;
      }
    }

    // Verify all 13 stores exist in the backup and contain valid arrays
    for (const storeName of EXPECTED_STORES) {
      if (!Array.isArray(backup.data[storeName])) {
        result.error = `الجدول "${storeName}" مفقود من النسخة الاحتياطية.`;
        return result;
      }

      // Check array elements are valid non-null objects (R-17-META)
      const arr = backup.data[storeName];
      for (let i = 0; i < arr.length; i++) {
        const item = arr[i];
        if (item === null || item === undefined || typeof item !== "object") {
          result.error = `الجدول "${storeName}" يحتوي على سجل غير صالح في الموضع ${i}.`;
          return result;
        }
      }

      const count = arr.length;
      result.storeCounts[storeName] = count;
      result.totalRecords += count;
    }

    // If sourceCounts is provided (creation / safety check mode against live IDB):
    // Validate complete 13-store structure and exact match (R-20)
    if (sourceCounts !== undefined && sourceCounts !== null) {
      if (typeof sourceCounts !== "object" || Array.isArray(sourceCounts)) {
        result.error = "بنية sourceCounts غير صالحة.";
        return result;
      }
      for (const storeName of EXPECTED_STORES) {
        if (
          typeof sourceCounts[storeName] !== "number" ||
          !Number.isSafeInteger(sourceCounts[storeName]) ||
          sourceCounts[storeName] < 0
        ) {
          result.error = `العدد المرجعي للجدول "${storeName}" في sourceCounts غير صالح أو مفقود.`;
          return result;
        }
        if (result.storeCounts[storeName] !== sourceCounts[storeName]) {
          result.error = `عدم تطابق عدد السجلات في جدول "${storeName}": المصدر الحي (${sourceCounts[storeName]}) مقابل النسخة (${result.storeCounts[storeName]}).`;
          return result;
        }
      }
      result.countsMatch = true;
    }

    // Verify integrity hash (SEC-02: Mandatory checksum validation for V2 backups)
    const canonicalData = JSON.stringify(backup.data);
    const computedHash = await computeSha256(canonicalData);
    result.checksum = computedHash;

    const isV2 = backup.backupFormat === BACKUP_FORMAT_VERSION;
    if (isV2) {
      if (!backup.integrity || typeof backup.integrity !== "object" || Array.isArray(backup.integrity)) {
        result.error = "حقل سلامة البيانات (integrity) مفقود من النسخة الاحتياطية.";
        return result;
      }

      // Checksum validation (SEC-02: Mandatory checksum validation for V2 backups)
      if (typeof backup.integrity.checksum !== "string" || !backup.integrity.checksum.trim()) {
        result.error = "بصمة التحقق الرقمية (checksum) مفقودة أو غير صالحة في النسخة الاحتياطية.";
        return result;
      }
      const normChecksum = backup.integrity.checksum.trim().toLowerCase();
      if (!/^[0-9a-f]{64}$/.test(normChecksum)) {
        result.error = "صيغة البصمة الرقمية (checksum) غير صالحة — يجب أن تكون 64 رمزاً ست عشرياً.";
        return result;
      }
      if (normChecksum !== computedHash.toLowerCase()) {
        result.error = "فشل التحقق من البصمة الرقمية (Checksum Mismatch). البيانات قد تكون تالفة أو تم تعديلها.";
        return result;
      }

      // C. integrity.algorithm: MUST be exactly "SHA-256" (R-17-META)
      if (typeof backup.integrity.algorithm !== "string" || backup.integrity.algorithm !== "SHA-256") {
        result.error = `خوارزمية البصمة الرقمية غير صالحة أو غير مدعومة: "${backup.integrity.algorithm}" — يجب أن تكون "SHA-256".`;
        return result;
      }

      // B. integrity.totalRecords: MUST be mandatory, safe non-negative integer, and match actual sum (R-08 / R-17-META)
      const declaredTotal = backup.integrity.totalRecords;
      if (
        declaredTotal === undefined ||
        declaredTotal === null ||
        typeof declaredTotal !== "number" ||
        !Number.isSafeInteger(declaredTotal) ||
        declaredTotal < 0
      ) {
        result.error = `حقل إجمالي السجلات (totalRecords) غير صالح أو مفقود في كائن السلامة للنسخة V2 (${declaredTotal}).`;
        return result;
      }
      if (declaredTotal !== result.totalRecords) {
        result.error = `عدم تطابق إجمالي السجلات المعلن (${declaredTotal}) مع مجموع السجلات الفعلي (${result.totalRecords}) في النسخة الاحتياطية (R-08).`;
        return result;
      }

      // A. recordCounts: MUST be mandatory, plain object (not null, not array), exactly all 13 stores (R-08)
      if (
        !backup.recordCounts ||
        typeof backup.recordCounts !== "object" ||
        Array.isArray(backup.recordCounts)
      ) {
        result.error = "حقل أعداد السجلات (recordCounts) غير صالح أو مفقود في النسخة الاحتياطية V2.";
        return result;
      }
      const recordCountKeys = Object.keys(backup.recordCounts);
      for (const k of recordCountKeys) {
        if (!EXPECTED_STORES.includes(k as any)) {
          result.error = `حقل recordCounts يحتوي على جدول غير معروف: "${k}".`;
          return result;
        }
      }
      for (const storeName of EXPECTED_STORES) {
        const declaredCount = backup.recordCounts[storeName];
        if (declaredCount === undefined) {
          result.error = `العدد المعلن للجدول "${storeName}" في recordCounts غير صالح أو مفقود (R-08).`;
          return result;
        }
        if (
          typeof declaredCount !== "number" ||
          !Number.isSafeInteger(declaredCount) ||
          declaredCount < 0
        ) {
          result.error = `العدد المعلن للجدول "${storeName}" في recordCounts غير صالح (${declaredCount}).`;
          return result;
        }
        if (declaredCount !== result.storeCounts[storeName]) {
          result.error = `عدم تطابق عدد سجلات الجدول "${storeName}": المعلن في recordCounts (${declaredCount}) مقابل الفعلي (${result.storeCounts[storeName]}) (R-08).`;
          return result;
        }
      }

      // D. schemaVersion: MUST be mandatory, valid SemVer string (R-17-META)
      if (
        backup.schemaVersion === undefined ||
        backup.schemaVersion === null ||
        typeof backup.schemaVersion !== "string" ||
        !isValidSemVer(backup.schemaVersion)
      ) {
        result.error = `إصدار المخطط في النسخة الاحتياطية (${backup?.schemaVersion}) غير صالح أو مفقود (R-17-META).`;
        return result;
      }

      // E. databaseVersion: MUST be mandatory, safe positive integer (R-19)
      if (
        backup.databaseVersion === undefined ||
        backup.databaseVersion === null ||
        typeof backup.databaseVersion !== "number" ||
        !Number.isSafeInteger(backup.databaseVersion) ||
        backup.databaseVersion <= 0
      ) {
        result.error = `إصدار قاعدة البيانات في النسخة الاحتياطية (${backup?.databaseVersion}) غير صالح أو مفقود (R-19).`;
        return result;
      }
    } else if (backup.integrity?.checksum) {
      // Legacy backup: if checksum is present, it must be valid and match
      if (
        typeof backup.integrity.checksum !== "string" ||
        backup.integrity.checksum.trim().toLowerCase() !== computedHash.toLowerCase()
      ) {
        result.error = "فشل التحقق من البصمة الرقمية للنسخة الاحتياطية.";
        return result;
      }
      if (backup.integrity.totalRecords !== undefined) {
        // nonTransientTotal: result.totalRecords already includes all settings records (including
        // any transient plms_update_state key that may have been exported by legacy creators).
        // Allow declared total to match either the full count OR the non-transient count so that
        // legacy backups created before transient-key filtering are still accepted.
        const nonTransientTotal = result.totalRecords -
          ((backup.data["settings"] as any[] || []).filter((r: any) => r?.key === "plms_update_state").length);
        if (backup.integrity.totalRecords !== result.totalRecords && backup.integrity.totalRecords !== nonTransientTotal) {
          result.error = `عدم تطابق إجمالي السجلات في النسخة القديمة (${backup.integrity.totalRecords} مقابل ${result.totalRecords}).`;
          return result;
        }
      }
    }

    // Verify JSON parse roundtrip
    const reSerialized = JSON.stringify(backup);
    const reParsed = JSON.parse(reSerialized);
    if (!reParsed || !reParsed.data) {
      result.error = "فشل اختبار إعادة قراءة النسخة الاحتياطية (Roundtrip Parse Failed).";
      return result;
    }

    result.valid = true;
    return result;
  } catch (err: any) {
    result.error = `خطأ أثناء التحقق من النسخة الاحتياطية: ${err?.message || String(err)}`;
    return result;
  }
}

// ── B-01 / C-01: STRICT RELATIONAL INTEGRITY VALIDATION (POLICY A) ──

export const STORES_WITH_MANDATORY_DAY: readonly string[] = [
  "dayReopenLogs",
  "openingStock",
  "loads",
  "additions",
  "unloads",
  "damages",
  "discounts",
  "closingStock",
  "dayPriceSnapshot"
];

export const STORES_WITH_MANDATORY_PRODUCT: readonly string[] = [
  "openingStock",
  "loads",
  "additions",
  "unloads",
  "damages",
  "closingStock",
  "dayPriceSnapshot"
];

export interface RelationalValidationOptions {
  mode: "REPLACE" | "MERGE";
  incomingData: Record<string, any[]>;
  liveProducts?: any[];
  liveDays?: any[];
}

export interface RelationalValidationResult {
  valid: boolean;
  error?: string;
  resultingProductIds: Set<number>;
  resultingDayIds: Set<number>;
}

export function validateRelationalIntegrity(
  options: RelationalValidationOptions
): RelationalValidationResult {
  const resultingProductIds = new Set<number>();
  const resultingDayIds = new Set<number>();

  const isPositiveSafeInt = (val: any): val is number => {
    return typeof val === "number" && Number.isSafeInteger(val) && val > 0;
  };

  if (!options || typeof options !== "object" || !options.incomingData || typeof options.incomingData !== "object") {
    return { valid: false, error: "بيانات التحقق المرجعي غير صالحة.", resultingProductIds, resultingDayIds };
  }

  const incomingData = options.incomingData;

  if (options.mode === "REPLACE") {
    // In REPLACE mode, existing local tables are completely cleared.
    // Authoritative parent sets consist exclusively of incoming parents that will actually commit.
    const incomingProducts = incomingData["products"] || [];
    const seenProductCodes = new Set<string>();

    for (let i = 0; i < incomingProducts.length; i++) {
      const p = incomingProducts[i];
      if (!p || typeof p !== "object" || Array.isArray(p)) {
        return { valid: false, error: `سجل غير صالح في جدول products في الموضع ${i}`, resultingProductIds, resultingDayIds };
      }
      if (!isPositiveSafeInt(p.id)) {
        return { valid: false, error: `معرف صنف غير صالح أو مفقود في جدول products (سجل ${i})`, resultingProductIds, resultingDayIds };
      }
      if (resultingProductIds.has(p.id)) {
        return { valid: false, error: `معرف صنف مكرر داخل النسخة المستوردة: ${p.id}`, resultingProductIds, resultingDayIds };
      }
      resultingProductIds.add(p.id);

      if (typeof p.code === "string" && p.code.trim()) {
        const c = p.code.trim();
        if (seenProductCodes.has(c)) {
          return { valid: false, error: `كود صنف مكرر داخل النسخة المستوردة: "${c}"`, resultingProductIds, resultingDayIds };
        }
        seenProductCodes.add(c);
      }
    }

    const incomingDays = incomingData["days"] || [];
    const seenDayDates = new Set<string>();

    for (let i = 0; i < incomingDays.length; i++) {
      const d = incomingDays[i];
      if (!d || typeof d !== "object" || Array.isArray(d)) {
        return { valid: false, error: `سجل غير صالح في جدول days في الموضع ${i}`, resultingProductIds, resultingDayIds };
      }
      if (!isPositiveSafeInt(d.id)) {
        return { valid: false, error: `معرف يوم غير صالح أو مفقود في جدول days (سجل ${i})`, resultingProductIds, resultingDayIds };
      }
      if (resultingDayIds.has(d.id)) {
        return { valid: false, error: `معرف يوم مكرر داخل النسخة المستوردة: ${d.id}`, resultingProductIds, resultingDayIds };
      }
      resultingDayIds.add(d.id);

      if (typeof d.date === "string" && d.date.trim()) {
        const dt = d.date.trim();
        if (seenDayDates.has(dt)) {
          return { valid: false, error: `تاريخ يوم مكرر داخل النسخة المستوردة: "${dt}"`, resultingProductIds, resultingDayIds };
        }
        seenDayDates.add(dt);
      }
    }
  } else if (options.mode === "MERGE") {
    // In MERGE mode, existing local live records are retained unless collision rules dictate otherwise.
    const liveProducts = options.liveProducts || [];
    const liveDays = options.liveDays || [];

    const localById = new Map<number, any>();
    const localByCode = new Map<string, any>();
    for (const p of liveProducts) {
      if (p && isPositiveSafeInt(p.id)) {
        localById.set(p.id, p);
        resultingProductIds.add(p.id);
      }
      if (p && typeof p.code === "string" && p.code.trim()) {
        localByCode.set(p.code.trim(), p);
      }
    }

    const incomingProducts = incomingData["products"] || [];
    const seenIncomingCodes = new Set<string>();
    const seenIncomingIds = new Set<number>();

    for (const rec of incomingProducts) {
      if (!rec || typeof rec !== "object" || Array.isArray(rec)) continue;
      const cleanCode = typeof rec.code === "string" ? rec.code.trim() : "";
      if (!cleanCode) {
        return { valid: false, error: "صنف ببيانات رمز غير صالحة في النسخة المستوردة", resultingProductIds, resultingDayIds };
      }
      if (seenIncomingCodes.has(cleanCode)) {
        return { valid: false, error: `كود صنف مكرر داخل النسخة المستوردة: "${cleanCode}"`, resultingProductIds, resultingDayIds };
      }
      seenIncomingCodes.add(cleanCode);

      if (rec.id !== undefined) {
        if (!isPositiveSafeInt(rec.id)) {
          return { valid: false, error: `معرف صنف غير صالح في النسخة المستوردة: ${rec.id}`, resultingProductIds, resultingDayIds };
        }
        if (seenIncomingIds.has(rec.id)) {
          return { valid: false, error: `معرف صنف مكرر داخل النسخة المستوردة: ${rec.id}`, resultingProductIds, resultingDayIds };
        }
        seenIncomingIds.add(rec.id);
      }

      const existCode = localByCode.get(cleanCode);
      const existId = rec.id !== undefined ? localById.get(rec.id) : null;

      if (existCode && rec.id !== undefined && existCode.id !== rec.id) {
        return { valid: false, error: `تعارض كود صنف مع قاعدة البيانات المحلية: الكود "${cleanCode}" مسجل محلياً للصنف معرف ${existCode.id}، بينما يحمل المعرف ${rec.id} في النسخة المستوردة`, resultingProductIds, resultingDayIds };
      }
      if (existId && existId.code?.trim() !== cleanCode) {
        return { valid: false, error: `تعارض معرف صنف مع قاعدة البيانات المحلية: المعرف ${rec.id} مسجل محلياً للكود "${existId.code}"، بينما يحمل الكود "${cleanCode}" في النسخة المستوردة`, resultingProductIds, resultingDayIds };
      }
      if (rec.id === undefined && existCode) {
        return { valid: false, error: `تعارض كود صنف مع قاعدة البيانات المحلية: الكود "${cleanCode}" موجود بالفعل محلياً بدون تحديد معرف في النسخة`, resultingProductIds, resultingDayIds };
      }

      if (rec.id !== undefined) {
        resultingProductIds.add(rec.id);
      }
    }

    const localDaysById = new Map<number, any>();
    const localDaysByDate = new Map<string, any>();
    for (const d of liveDays) {
      if (d && isPositiveSafeInt(d.id)) {
        localDaysById.set(d.id, d);
        resultingDayIds.add(d.id);
      }
      if (d && typeof d.date === "string" && d.date.trim()) {
        localDaysByDate.set(d.date.trim(), d);
      }
    }

    const incomingDays = incomingData["days"] || [];
    const seenIncomingDates = new Set<string>();
    const seenIncomingDayIds = new Set<number>();

    for (const d of incomingDays) {
      if (!d || typeof d !== "object" || Array.isArray(d)) continue;
      const cleanDate = typeof d.date === "string" ? d.date.trim() : "";
      if (!cleanDate) {
        return { valid: false, error: "تاريخ يوم غير صالح في النسخة المستوردة", resultingProductIds, resultingDayIds };
      }
      if (seenIncomingDates.has(cleanDate)) {
        return { valid: false, error: `تاريخ يوم مكرر داخل النسخة المستوردة: "${cleanDate}"`, resultingProductIds, resultingDayIds };
      }
      seenIncomingDates.add(cleanDate);

      if (d.id !== undefined) {
        if (!isPositiveSafeInt(d.id)) {
          return { valid: false, error: `معرف يوم غير صالح في النسخة المستوردة: ${d.id}`, resultingProductIds, resultingDayIds };
        }
        if (seenIncomingDayIds.has(d.id)) {
          return { valid: false, error: `معرف يوم مكرر داخل النسخة المستوردة: ${d.id}`, resultingProductIds, resultingDayIds };
        }
        seenIncomingDayIds.add(d.id);
      }

      const existDate = localDaysByDate.get(cleanDate);
      const existDayId = d.id !== undefined ? localDaysById.get(d.id) : null;

      if (existDate && d.id !== undefined && existDate.id !== d.id) {
        return { valid: false, error: `تعارض تاريخ يوم مع قاعدة البيانات المحلية: التاريخ "${cleanDate}" مسجل محلياً لليوم معرف ${existDate.id}، بينما يحمل المعرف ${d.id} في النسخة المستوردة`, resultingProductIds, resultingDayIds };
      }
      if (existDayId && existDayId.date?.trim() !== cleanDate) {
        return { valid: false, error: `تعارض معرف يوم مع قاعدة البيانات المحلية: المعرف ${d.id} مسجل محلياً للتاريخ "${existDayId.date}"، بينما يحمل التاريخ "${cleanDate}" في النسخة المستوردة`, resultingProductIds, resultingDayIds };
      }

      if (d.id !== undefined) {
        resultingDayIds.add(d.id);
      }
    }
  } else {
    return { valid: false, error: `نمط الاستعادة غير معروف: ${(options as any).mode}`, resultingProductIds, resultingDayIds };
  }

  // Authoritative Policy A Validation across all child stores:
  // Validate mandatory dayId stores (9 stores)
  for (const sName of STORES_WITH_MANDATORY_DAY) {
    const rows = incomingData[sName] || [];
    for (let i = 0; i < rows.length; i++) {
      const rec = rows[i];
      if (!rec || typeof rec !== "object" || Array.isArray(rec)) {
        return { valid: false, error: `سجل غير صالح في جدول ${sName} في الموضع ${i}`, resultingProductIds, resultingDayIds };
      }

      // Explicit non-truthiness check: missing, null, empty string, non-safe-int, <= 0
      if (rec.dayId === undefined || rec.dayId === null || rec.dayId === "" || !isPositiveSafeInt(rec.dayId)) {
        return {
          valid: false,
          error: `خطأ علاقة مرجعية: المعرف dayId مفقود أو غير صالح في جدول ${sName}${rec.id !== undefined ? ` (سجل معرف: ${rec.id})` : ` (سجل في الموضع ${i})`}`,
          resultingProductIds,
          resultingDayIds
        };
      }

      if (!resultingDayIds.has(rec.dayId)) {
        return {
          valid: false,
          error: `خطأ علاقة مرجعية: مرجع يوم غير موجود (${rec.dayId}) في جدول ${sName}`,
          resultingProductIds,
          resultingDayIds
        };
      }
    }
  }

  // Validate mandatory productId stores (7 stores)
  for (const sName of STORES_WITH_MANDATORY_PRODUCT) {
    const rows = incomingData[sName] || [];
    for (let i = 0; i < rows.length; i++) {
      const rec = rows[i];
      if (!rec || typeof rec !== "object" || Array.isArray(rec)) {
        return { valid: false, error: `سجل غير صالح في جدول ${sName} في الموضع ${i}`, resultingProductIds, resultingDayIds };
      }

      // Explicit non-truthiness check: missing, null, empty string, non-safe-int, <= 0
      if (rec.productId === undefined || rec.productId === null || rec.productId === "" || !isPositiveSafeInt(rec.productId)) {
        return {
          valid: false,
          error: `خطأ علاقة مرجعية: المعرف productId مفقود أو غير صالح في جدول ${sName}${rec.id !== undefined ? ` (سجل معرف: ${rec.id})` : ` (سجل في الموضع ${i})`}`,
          resultingProductIds,
          resultingDayIds
        };
      }

      if (!resultingProductIds.has(rec.productId)) {
        return {
          valid: false,
          error: `خطأ علاقة مرجعية: مرجع صنف غير موجود (${rec.productId}) في جدول ${sName}`,
          resultingProductIds,
          resultingDayIds
        };
      }
    }
  }

  return {
    valid: true,
    resultingProductIds,
    resultingDayIds
  };
}

// ── RECOVERY STORAGE: CACHE STORAGE IMPLEMENTATION ───────────────

export async function storeVerifiedRecoveryBackup(
  _db: IDBDatabase | null,
  backup: CompleteBackupPayload
): Promise<RecoveryIndexEntry> {
  const timestamp = backup.exportedAt || Date.now();
  const id = `rec_${timestamp}`;
  const storageKey = `recovery_backup_${id}`;

  const entry: RecoveryIndexEntry = {
    id,
    key: storageKey,
    timestamp,
    exportDate: backup.exportDate,
    driverName: backup.driverName,
    carNumber: backup.carNumber,
    totalRecords: backup.integrity.totalRecords,
    checksum: backup.integrity.checksum,
    appVersion: backup.appVersion,
    schemaVersion: backup.schemaVersion,
    databaseVersion: backup.databaseVersion
  };

  const cache = await getCacheStorage();
  if (!cache) {
    throw new Error(
      "Cache Storage غير متاح في هذا المتصفح. لا يمكن حفظ نسخة الاسترداد خارج قاعدة البيانات."
    );
  }

  // 1. Write full backup
  await writeCacheJson(cache, RECOVERY_BACKUP_URL_PREFIX + id, backup);

  // 2. Read back and verify checksum
  const readBack = await readCacheJson<CompleteBackupPayload>(
    cache,
    RECOVERY_BACKUP_URL_PREFIX + id
  );
  if (!readBack || readBack.integrity?.checksum !== backup.integrity.checksum) {
    throw new Error(
      "فشل التحقق من قراءة النسخة الاحتياطية بعد حفظها في Cache Storage."
    );
  }

  // 3. Read current recovery index (with fallback to legacy index if first write on Phase 8.3)
  let currentIndex = await readCacheJson<RecoveryIndexEntry[]>(cache, RECOVERY_INDEX_URL);
  if (!currentIndex || !Array.isArray(currentIndex)) {
    const legacyIndex = await readCacheJson<RecoveryIndexEntry[]>(cache, LEGACY_RECOVERY_INDEX_URL);
    currentIndex = (legacyIndex && Array.isArray(legacyIndex)) ? legacyIndex : [];
  }

  // Filter out any duplicate if same ID already in index
  const filteredCurrent = currentIndex.filter((e) => e.id !== entry.id);
  const newIndex = [entry, ...filteredCurrent];

  const toKeep = newIndex.slice(0, MAX_RECOVERY_BACKUPS);
  const toRemove = newIndex.slice(MAX_RECOVERY_BACKUPS);

  // 4. FAILURE-SAFE ROTATION: COMMIT UPDATED INDEX FIRST
  // The index is written and safely committed BEFORE any obsolete backups are deleted.
  // If this write fails, no existing recovery backup is ever deleted!
  await writeCacheJson(cache, RECOVERY_INDEX_URL, toKeep);

  // 5. ONLY AFTER INDEX IS COMMITTED: Prune obsolete backups beyond MAX_RECOVERY_BACKUPS
  // Invariant: Never delete an entry if it's in toKeep or is the only valid backup.
  if (toRemove.length > 0) {
    for (const oldEntry of toRemove) {
      // Safety guard: ensure entry is never in toKeep
      if (toKeep.some((k) => k.id === oldEntry.id)) continue;

      try {
        await cache.delete(RECOVERY_BACKUP_URL_PREFIX + oldEntry.id);
      } catch (delErr) {
        // Safe report: deletion failure of obsolete backup does NOT compromise recoverability
        console.warn(
          `[SafeUpdate] Warning: could not delete obsolete recovery backup ${oldEntry.id}:`,
          delErr
        );
      }
    }
  }

  return entry;
}

// ── RECOVERY INDEX & BACKUP RETRIEVAL ────────────────────────────

export async function getRecoveryBackupsIndex(
  _db?: IDBDatabase | null
): Promise<RecoveryIndexEntry[]> {
  try {
    const cache = await getCacheStorage();
    if (!cache) return [];
    const current = await readCacheJson<RecoveryIndexEntry[]>(cache, RECOVERY_INDEX_URL);
    if (current && Array.isArray(current)) return current;
    // Non-destructive fallback for legacy installations
    const legacy = await readCacheJson<RecoveryIndexEntry[]>(cache, LEGACY_RECOVERY_INDEX_URL);
    return (legacy && Array.isArray(legacy)) ? legacy : [];
  } catch {
    return [];
  }
}

export async function getRecoveryBackupByKey(
  _db: IDBDatabase | null,
  key: string
): Promise<CompleteBackupPayload | null> {
  try {
    const cache = await getCacheStorage();
    if (!cache) return null;
    // key is "recovery_backup_rec_<timestamp>", id is "rec_<timestamp>"
    const id = key.replace("recovery_backup_", "");
    const backup = await readCacheJson<CompleteBackupPayload>(
      cache,
      RECOVERY_BACKUP_URL_PREFIX + id
    );
    if (backup) return backup;
    // Non-destructive fallback for legacy keys
    return await readCacheJson<CompleteBackupPayload>(
      cache,
      LEGACY_RECOVERY_BACKUP_URL_PREFIX + id
    );
  } catch {
    return null;
  }
}

// ── VERSION COMPATIBILITY MATRIX ──────────────────────────────────

const SEMVER_STRICT_REGEX = /^(0|[1-9]\d*)\.(0|[1-9]\d*)\.(0|[1-9]\d*)$/;

export function isValidSemVer(v: any): v is string {
  if (typeof v !== "string" || /\s/.test(v) || !SEMVER_STRICT_REGEX.test(v)) {
    return false;
  }
  const parts = v.split(".");
  for (const p of parts) {
    try {
      if (BigInt(p) > BigInt(Number.MAX_SAFE_INTEGER)) return false;
    } catch {
      return false;
    }
  }
  return true;
}

export function parseStrictSemVer(v: string): [number, number, number] {
  if (!isValidSemVer(v)) {
    throw new Error(`Invalid SemVer format: ${v}`);
  }
  return v.split(".").map(Number) as [number, number, number];
}

export function checkVersionCompatibility(
  current: { appVersion: string; schemaVersion: string; dbVersion: number },
  target: { appVersion: string; schemaVersion: string; dbVersion: number }
): { compatible: boolean; reason?: string } {
  // 1. Strict validation of DB version (must be a positive safe integer <= MAX_SAFE_INTEGER)
  if (
    !current ||
    typeof current.dbVersion !== "number" ||
    !Number.isSafeInteger(current.dbVersion) ||
    current.dbVersion <= 0 ||
    !target ||
    typeof target.dbVersion !== "number" ||
    !Number.isSafeInteger(target.dbVersion) ||
    target.dbVersion <= 0
  ) {
    return {
      compatible: false,
      reason: "إصدار قاعدة البيانات غير صالح — يجب أن يكون عدداً صحيحاً موجباً وآمناً."
    };
  }

  // 2. Strict validation of schema version format (SemVer MAJOR.MINOR.PATCH, no whitespace, <= MAX_SAFE_INTEGER)
  if (!current.schemaVersion || !isValidSemVer(current.schemaVersion)) {
    return {
      compatible: false,
      reason: `صيغة إصدار المخطط الحالي (${current?.schemaVersion}) غير صالحة.`
    };
  }

  if (!target.schemaVersion || !isValidSemVer(target.schemaVersion)) {
    return {
      compatible: false,
      reason: `صيغة إصدار المخطط المستهدف (${target?.schemaVersion}) غير صالحة.`
    };
  }

  // 3. DB version: cannot downgrade
  if (target.dbVersion < current.dbVersion) {
    return {
      compatible: false,
      reason: "لا يمكن التراجع إلى إصدار قاعدة بيانات أقدم (DB Downgrade Blocked)."
    };
  }

  // 4. Schema version: parse and compare [major, minor, patch]
  const [currMaj, currMin, currPatch] = parseStrictSemVer(current.schemaVersion);
  const [targMaj, targMin, targPatch] = parseStrictSemVer(target.schemaVersion);

  // Downgrade check (major, minor, or patch)
  if (
    targMaj < currMaj ||
    (targMaj === currMaj && targMin < currMin) ||
    (targMaj === currMaj && targMin === currMin && targPatch < currPatch)
  ) {
    return {
      compatible: false,
      reason: "لا يمكن التراجع إلى إصدار Schema قديم (Schema Downgrade Blocked)."
    };
  }

  // Jumping across multiple major schema versions without an intermediate upgrade path
  if (targMaj > currMaj + 1) {
    return {
      compatible: false,
      reason: "الترقية تتطلب الانتقال عبر إصدار مرحلي وسيط أولاً."
    };
  }

  return { compatible: true };
}

// ── POST-UPDATE VERIFICATION ──────────────────────────────────────

export async function runPostUpdateVerification(
  db: IDBDatabase,
  expectedCounts?: Record<string, number>
): Promise<PostUpdateVerificationResult> {
  const details: PostUpdateVerificationResult["details"] = {
    dbOpened: false,
    storesCount: 0,
    storesMatch: false,
    dbVersionMatch: false,
    schemaVersionMatch: false,
    recordsAccessible: false,
    settingsAccessible: false,
    noSalesStore: true
  };

  try {
    if (!db) {
      return {
        passed: false,
        error: "فشل فتح قاعدة البيانات بعد التحديث.",
        details
      };
    }
    details.dbOpened = true;
    details.storesCount = db.objectStoreNames.length;

    // Strict check: NO sales store (must be rejected immediately)
    if (db.objectStoreNames.contains("sales")) {
      details.noSalesStore = false;
      return {
        passed: false,
        error: 'تم اكتشاف جدول "sales" غير مسموح به في قاعدة البيانات.',
        details
      };
    }

    // Check store count is EXACTLY 13
    if (details.storesCount !== EXPECTED_STORES.length) {
      return {
        passed: false,
        error: `عدد الجداول (${details.storesCount}) لا يطابق العدد المطلوب الصارم (${EXPECTED_STORES.length}).`,
        details
      };
    }

    // Check every expected store exists
    const missing = EXPECTED_STORES.filter((s) => !db.objectStoreNames.contains(s));
    if (missing.length > 0) {
      return {
        passed: false,
        error: `الجداول التالية مفقودة بعد التحديث: ${missing.join(", ")}`,
        details
      };
    }
    details.storesMatch = true;

    // Check DB version
    if (db.version !== DB_VERSION) {
      return {
        passed: false,
        error: `إصدار قاعدة البيانات (${db.version}) لا يطابق الإصدار المطلوب (${DB_VERSION}).`,
        details
      };
    }
    details.dbVersionMatch = true;

    // Verify records accessibility and collect actual counts in all 13 stores
    const actualCounts: Record<string, number> = {};
    for (const s of EXPECTED_STORES) {
      const count = await new Promise<number>((resolve, reject) => {
        try {
          const tx = db.transaction(s, "readonly");
          const store = tx.objectStore(s);
          const req = store.count();
          req.onsuccess = () => resolve(req.result);
          req.onerror = () => reject(req.error);
        } catch (e) {
          reject(e);
        }
      });
      actualCounts[s] = count;
    }
    details.recordsAccessible = true;

    // Verify expectedCounts if provided (strict policy: all 13 stores must be present, no extra keys, valid non-negative integers)
    if (expectedCounts !== undefined && expectedCounts !== null) {
      if (typeof expectedCounts !== "object" || Array.isArray(expectedCounts)) {
        return {
          passed: false,
          error: "المعامل expectedCounts غير صالح — يجب أن يكون كائناً صحيحاً.",
          details
        };
      }

      // 1. Strict policy for extra keys: every key must be in EXPECTED_STORES
      const extraKeys = Object.keys(expectedCounts).filter((k) => !EXPECTED_STORES.includes(k as any));
      if (extraKeys.length > 0) {
        return {
          passed: false,
          error: `تم العثور على جداول غير متوقعة في expectedCounts: ${extraKeys.join(", ")}`,
          details
        };
      }

      // 2. Strict policy for missing stores: all 13 stores must be explicitly covered
      const missingStores = EXPECTED_STORES.filter((s) => !(s in expectedCounts));
      if (missingStores.length > 0) {
        return {
          passed: false,
          error: `جداول مطلوبة مفقودة من expectedCounts: ${missingStores.join(", ")}`,
          details
        };
      }

      // 3. Strict validation of counts: safe non-negative integer & match actual counts
      for (const s of EXPECTED_STORES) {
        const exp = (expectedCounts as Record<string, any>)[s];
        if (typeof exp !== "number" || !Number.isSafeInteger(exp) || exp < 0) {
          return {
            passed: false,
            error: `العدد المتوقع للجدول "${s}" غير صالح (${exp}) — يجب أن يكون عدداً صحيحاً آمناً غير سالب.`,
            details
          };
        }
        if (actualCounts[s] !== exp) {
          return {
            passed: false,
            error: `عدد السجلات في جدول "${s}" (${actualCounts[s]}) لا يطابق العدد المتوقع (${exp}).`,
            details
          };
        }
      }
      details.recordCountsMatch = true;
    }

    // Verify settings accessible and strictly validate application settings record
    const appSettings = await new Promise<any>((resolve, reject) => {
      try {
        const tx = db.transaction("settings", "readonly");
        const store = tx.objectStore("settings");
        const req = store.get("app");
        req.onsuccess = () => {
          const res = req.result;
          if (res && typeof res === "object" && "value" in res) {
            resolve(res.value);
          } else {
            resolve(res);
          }
        };
        req.onerror = () => reject(req.error);
      } catch (e) {
        reject(e);
      }
    });

    if (!appSettings || typeof appSettings !== "object") {
      details.settingsAccessible = false;
      details.schemaVersionMatch = false;
      return {
        passed: false,
        error: 'إعدادات التطبيق الأساسية ("app") مفقودة أو غير صالحة في جدول settings بعد التحديث.',
        details
      };
    }

    details.settingsAccessible = true;

    // Strict validation of Schema Version against SCHEMA_VERSION
    const actualSchema = appSettings.schemaVersion ?? appSettings.value?.schemaVersion;
    if (!actualSchema || typeof actualSchema !== "string" || actualSchema.trim() !== SCHEMA_VERSION) {
      details.schemaVersionMatch = false;
      return {
        passed: false,
        error: `إصدار المخطط في الإعدادات (${actualSchema || "مفقود"}) لا يطابق إصدار المخطط المطلوب الصارم (${SCHEMA_VERSION}).`,
        details
      };
    }

    details.schemaVersionMatch = true;

    return {
      passed: true,
      details
    };
  } catch (err: any) {
    return {
      passed: false,
      error: `فشل التحقق بعد التحديث: ${err?.message || String(err)}`,
      details
    };
  }
}

// ── RESTORE FROM RECOVERY BACKUP ──────────────────────────────────

export async function restoreFromVerifiedBackup(
  db: IDBDatabase,
  backup: CompleteBackupPayload
): Promise<{ success: boolean; totalRestored: number; message: string }> {
  // 1a. Verify backup structure & metadata strictly before any DB operations
  if (!backup || typeof backup !== "object" || !backup.data || typeof backup.data !== "object") {
    throw new Error("ملف النسخة الاحتياطية غير صالح.");
  }

  // Pre-modification validation: Strictly require valid schemaVersion and reject incompatible schema
  // before any store is cleared or modified (R-01)
  if (!backup.schemaVersion || typeof backup.schemaVersion !== "string" || !isValidSemVer(backup.schemaVersion)) {
    throw new Error(
      `إصدار المخطط في النسخة الاحتياطية (${backup?.schemaVersion}) غير صالح أو مفقود — تم رفض النسخة قبل إجراء أي تعديل (R-01).`
    );
  }

  if (backup.schemaVersion !== SCHEMA_VERSION) {
    throw new Error(
      `إصدار المخطط في النسخة الاحتياطية (${backup.schemaVersion}) لا يطابق إصدار المخطط المطلوب (${SCHEMA_VERSION}) — تم رفض النسخة قبل إجراء أي تعديل لمنع التلف (R-01).`
    );
  }

  const backupDbVersion = backup.databaseVersion;
  if (
    backupDbVersion === undefined ||
    backupDbVersion === null ||
    typeof backupDbVersion !== "number" ||
    !Number.isSafeInteger(backupDbVersion) ||
    backupDbVersion <= 0
  ) {
    throw new Error(
      `إصدار قاعدة البيانات في النسخة الاحتياطية (${backup?.databaseVersion}) غير صالح أو مفقود — تم رفض النسخة قبل إجراء أي تعديل (R-01).`
    );
  }

  // 1b. Verify integrity & metadata of the backup before restoring (R-08, R-17-META, R-20)
  // Do NOT pass circular self-counts as sourceCounts; verifyBackupPayload strictly validates
  // internal metadata consistency (totalRecords, recordCounts, checksum, schema, databaseVersion).
  const verif = await verifyBackupPayload(backup);
  if (!verif.valid) {
    throw new Error(`فشل التحقق من سلامة النسخة قبل الاستعادة: ${verif.error}`);
  }

  // 1c. Verify version compatibility using raw backup versions (NO fallbacks)
  const compat = checkVersionCompatibility(
    {
      appVersion: backup.appVersion || APP_VERSION,
      schemaVersion: backup.schemaVersion,
      dbVersion: backupDbVersion
    },
    {
      appVersion: APP_VERSION,
      schemaVersion: SCHEMA_VERSION,
      dbVersion: db?.version || DB_VERSION
    }
  );
  if (!compat.compatible) {
    throw new Error(`لا يمكن استعادة النسخة الاحتياطية بسبب عدم التوافق: ${compat.reason}`);
  }

  // 1d. Read existing settings to preserve device-specific security credentials (SEC-03 / R-03)
  // Fail-Closed Policy: Any error reading credentials MUST halt restore before any table is modified.
  const existingSettingsMap = new Map<string, any>();
  try {
    await new Promise<void>((resolve, reject) => {
      try {
        const tx = db.transaction("settings", "readonly");
        const store = tx.objectStore("settings");

        if (typeof store.openCursor === "function") {
          const req = store.openCursor();
          req.onsuccess = (e: any) => {
            const cursor = req.result ?? e?.target?.result ?? (e as any)?.result;
            if (cursor) {
              existingSettingsMap.set(String(cursor.key), cursor.value);
              cursor.continue();
            } else {
              resolve();
            }
          };
          req.onerror = (e: any) => {
            reject(req.error || (e?.target as any)?.error || new Error("فشل طلب قراءة سجلات الإعدادات عبر openCursor."));
          };
        } else if (typeof store.getAll === "function") {
          const req = store.getAll();
          req.onsuccess = (e: any) => {
            const results = req.result ?? e?.target?.result ?? (e as any)?.result ?? [];
            for (const rec of results) {
              if (rec && typeof rec === "object") {
                const k = rec.key ?? rec.id;
                if (k !== undefined) {
                  existingSettingsMap.set(String(k), rec.value ?? rec);
                }
              }
            }
            resolve();
          };
          req.onerror = (e: any) => {
            reject(req.error || (e?.target as any)?.error || new Error("فشل طلب قراءة سجلات الإعدادات عبر getAll."));
          };
        } else {
          reject(new Error("محرك قاعدة البيانات لا يدعم قراءة جدول الإعدادات."));
        }

        tx.onerror = (e: any) => {
          reject(tx.error || (e?.target as any)?.error || new Error("فشلت معاملة قراءة الإعدادات المحلية."));
        };
        tx.onabort = (e: any) => {
          reject(tx.error || (e?.target as any)?.error || new Error("تم إلغاء معاملة قراءة الإعدادات المحلية."));
        };
      } catch (startErr) {
        reject(startErr);
      }
    });
  } catch (err: any) {
    throw new Error(
      `فشل قراءة بيانات الاعتماد المحلية للجهاز من جدول الإعدادات — تم إيقاف الاستعادة فورياً لحماية بيانات الاعتماد (R-03): ${err?.message || String(err)}`
    );
  }

  // B-01 / C-01: Strict relational integrity validation (Policy A — All-or-Nothing) — REPLACE mode
  // All validation runs BEFORE the atomic write transaction begins.
  // For V2 REPLACE: authoritative parent sets are built from incoming backup data only.
  // This prevents orphaned child records and enforces referential integrity before any write.
  const relValResult = validateRelationalIntegrity({
    mode: "REPLACE",
    incomingData: backup.data as Record<string, any[]>
  });
  if (!relValResult.valid) {
    throw new Error(
      `رفض الاستعادة — خطأ في التحقق من سلامة العلاقات المرجعية (B-01 / السياسة أ — كل شيء أو لا شيء): ${relValResult.error}`
    );
  }

  // Helper to resolve local credential across both storage models (embedded in app OR standalone in settings)
  const getLocalCredential = (field: (typeof PROTECTED_SECURITY_FIELDS)[number]): any => {
    // 1. Check embedded inside local "app" record
    const existingAppRec = existingSettingsMap.get("app");
    const existingVal = existingAppRec?.value;
    if (existingVal && typeof existingVal === "object" && existingVal[field] !== undefined) {
      return existingVal[field];
    }
    // 2. Check standalone record in settings store
    if (existingSettingsMap.has(field)) {
      const standalone = existingSettingsMap.get(field);
      if (standalone !== undefined && standalone !== null) {
        if (typeof standalone === "object" && "value" in standalone && standalone.value !== undefined) {
          return standalone.value;
        }
        return standalone;
      }
    }
    return undefined;
  };

  const prepareSettingsRecord = (rec: any): any => {
    if (rec.key === "app" && rec.value && typeof rec.value === "object") {
      const merged = { ...rec.value };
      // Only inherit schemaVersion from backup metadata if missing from the record value;
      // do NOT fabricate or force SCHEMA_VERSION to ensure incompatible backups fail verification!
      if (!merged.schemaVersion && backup.schemaVersion) {
        merged.schemaVersion = backup.schemaVersion;
      }

      // For every protected security credential:
      // If the local device has an established credential (either embedded or standalone),
      // preserve the local credential value with absolute precedence.
      // If the local device does NOT have this credential (e.g. fresh device or un-enrolled profile),
      // STRICT FAIL-SECURE: Foreign credentials from another device's backup MUST NOT be imported!
      // This guarantees that initial security setup (First-Run / PIN wizard) is never bypassed
      // and foreign device credentials can never hijack this device.
      for (const field of PROTECTED_SECURITY_FIELDS) {
        const localCred = getLocalCredential(field);
        if (localCred !== undefined) {
          merged[field] = localCred;
        } else {
          delete merged[field];
        }
      }
      return { ...rec, value: merged };
    }
    if (PROTECTED_SECURITY_FIELDS.includes(rec.key as any)) {
      const field = rec.key as (typeof PROTECTED_SECURITY_FIELDS)[number];
      const localCred = getLocalCredential(field);
      if (localCred !== undefined) {
        return typeof localCred === "object" && localCred !== null && "key" in localCred
          ? localCred
          : { key: field, value: localCred };
      }
      // If local device does not have this standalone security credential,
      // strictly do NOT import foreign device credentials from backup (R-02 / SEC-03)
      return null;
    }
    return rec;
  };

  // 2. Clear and restore records atomically across all operational stores (R-01)
  // Single atomic multi-store transaction across all 13 stores
  let multiStoreTxInitiated = false;
  let totalRestored = 0;

  try {
    await new Promise<void>((resolve, reject) => {
      let tx: IDBTransaction;
      try {
        tx = db.transaction(EXPECTED_STORES, "readwrite");
        multiStoreTxInitiated = true;
      } catch (creationErr) {
        reject(creationErr);
        return;
      }

      let count = 0;
      let hasFailed = false;

      const failFast = (err: any) => {
        if (!hasFailed) {
          hasFailed = true;
          try {
            tx.abort();
          } catch {
            /* transaction may already be aborted or inactive */
          }
          reject(err);
        }
      };

      try {
        for (const storeName of EXPECTED_STORES) {
          const records = backup.data[storeName] || [];
          const store = tx.objectStore(storeName);

          if (storeName === "settings") {
            // R-02: Clean replacement for settings store.
            // Clear all existing settings records within the atomic multi-store transaction
            // so that stale keys from old states/schemas not in the backup are cleanly removed.
            const clearReq = store.clear();
            clearReq.onerror = (e: any) => {
              failFast(clearReq.error || (e?.target as any)?.error || new Error(`فشل مسح جدول ${storeName}`));
            };

            const writtenKeys = new Set<string>();

            // Restore and sanitize incoming backup records
            for (const rec of records) {
              if (
                rec.key === "plms_update_state" ||
                rec.key === "recovery_index" ||
                String(rec.key).startsWith("recovery_backup_")
              ) {
                continue;
              }
              const finalRec = prepareSettingsRecord(rec);
              if (!finalRec) {
                // Foreign standalone credential rejected
                continue;
              }
              const putReq = store.put(finalRec);
              putReq.onerror = (e: any) => {
                failFast(putReq.error || (e?.target as any)?.error || new Error(`فشل حفظ سجل في جدول ${storeName}`));
              };
              writtenKeys.add(String(rec.key));
              count++;
            }

            // Preserve local standalone security credentials from allowlist if omitted from backup (R-02 / SEC-03)
            for (const allowKey of LOCAL_SETTINGS_PRESERVE_ALLOWLIST) {
              if (existingSettingsMap.has(allowKey) && !writtenKeys.has(allowKey)) {
                const localRec = existingSettingsMap.get(allowKey);
                if (localRec !== undefined && localRec !== null) {
                  const recToPut =
                    typeof localRec === "object" && localRec !== null && localRec.key !== undefined
                      ? localRec
                      : { key: allowKey, value: localRec };
                  const putReq = store.put(recToPut);
                  putReq.onerror = (e: any) => {
                    failFast(putReq.error || (e?.target as any)?.error || new Error(`فشل حفظ سجل الإعدادات المحلي (${allowKey})`));
                  };
                  writtenKeys.add(allowKey);
                  count++;
                }
              }
            }
          } else {
            const clearReq = store.clear();
            clearReq.onerror = (e: any) => {
              failFast(clearReq.error || (e?.target as any)?.error || new Error(`فشل مسح جدول ${storeName}`));
            };
            for (const rec of records) {
              const putReq = store.put(rec);
              putReq.onerror = (e: any) => {
                failFast(putReq.error || (e?.target as any)?.error || new Error(`فشل حفظ سجل في جدول ${storeName}`));
              };
              count++;
            }
          }
        }
      } catch (dispatchErr) {
        failFast(dispatchErr);
        return;
      }

      tx.oncomplete = () => {
        // Individual request success is NOT transaction completion!
        // totalRestored is strictly set ONLY upon tx.oncomplete.
        totalRestored = count;
        resolve();
      };

      tx.onerror = (e: any) => {
        failFast(tx.error || (e?.target as any)?.error || new Error("فشلت معاملة استعادة البيانات في IndexedDB."));
      };

      tx.onabort = (e: any) => {
        failFast(tx.error || (e?.target as any)?.error || new Error("تم إلغاء معاملة الاستعادة لحماية البيانات (Transaction Aborted)."));
      };
    });
  } catch (err: any) {
    // R-01: If the multi-store transaction was initiated, any failure is a genuine transaction failure.
    // Under NO circumstances may fallback be executed after transaction initiation,
    // strictly preventing leaving the database in a partial restored state.
    if (multiStoreTxInitiated) {
      throw new Error(`فشلت معاملة الاستعادة الذرية وتم التراجع عن كافة التعديلات بأمان (R-01): ${err?.message || String(err)}`);
    }

    // If multi-store creation itself threw synchronously:
    // Check if error is a fatal DB error (e.g., closed connection, missing store, quota)
    const isFatal =
      err?.name === "InvalidStateError" ||
      err?.name === "NotFoundError" ||
      err?.name === "QuotaExceededError";
    if (isFatal) {
      throw err;
    }

    // In modern browsers, multi-store transactions are natively supported.
    // Throw error to fail closed and prevent unsafe partial commits.
    throw new Error(`لا يمكن بدء معاملة الاستعادة الذرية (R-01): ${err?.message || String(err)}`);
  }

  // 3. Post-restore verification
  const postVerify = await runPostUpdateVerification(db);
  if (!postVerify.passed) {
    throw new Error(`فشل التحقق من قاعدة البيانات بعد الاستعادة: ${postVerify.error}`);
  }

  return {
    success: true,
    totalRestored,
    message: `تم استعادة البيانات بنجاح (${totalRestored.toLocaleString("ar-EG")} سجل).`
  };
}

// ── PHASE 6.1: UNIVERSAL CARTON/UNIT QUANTITY BOUNDARY HARDENING ──

export interface QuantityValidationResult {
  valid: boolean;
  error?: string;
  cartons: number;
  units: number;
  totalUnits: number;
}

export function validateCartonUnitQuantity(
  cartonsVal: unknown,
  unitsVal: unknown,
  unitsPerCarton: number,
  productName?: string
): QuantityValidationResult {
  const upc = Number(unitsPerCarton);
  if (!Number.isFinite(upc) || upc <= 0) {
    return {
      valid: false,
      error: `عدد الوحدات في الكرتونة غير صالح${productName ? ` للصنف "${productName}"` : ""}.`,
      cartons: 0,
      units: 0,
      totalUnits: 0
    };
  }

  const cStr = String(cartonsVal ?? "").trim();
  const uStr = String(unitsVal ?? "").trim();

  const cParsed = cStr === "" ? 0 : Number(cStr);
  const uParsed = uStr === "" ? 0 : Number(uStr);

  if (!Number.isFinite(cParsed) || !Number.isInteger(cParsed) || cParsed < 0) {
    return {
      valid: false,
      error: `عدد الكراتين يجب أن يكون رقماً صحيحاً غير سالب${productName ? ` (${productName})` : ""}.`,
      cartons: 0,
      units: 0,
      totalUnits: 0
    };
  }

  if (!Number.isFinite(uParsed) || !Number.isInteger(uParsed) || uParsed < 0) {
    return {
      valid: false,
      error: `عدد العلب يجب أن يكون رقماً صحيحاً غير سالب${productName ? ` (${productName})` : ""}.`,
      cartons: cParsed,
      units: 0,
      totalUnits: 0
    };
  }

  // Strict boundary rule: 0 <= units < unitsPerCarton
  if (uParsed >= upc) {
    const prodLabel = productName ? ` (${productName})` : "";
    return {
      valid: false,
      error: `عدد العلب يجب أن يكون أقل من عدد الوحدات في الكرتونة${prodLabel}`,
      cartons: cParsed,
      units: uParsed,
      totalUnits: cParsed * upc + uParsed
    };
  }

  const totalUnits = cParsed * upc + uParsed;
  return {
    valid: true,
    cartons: cParsed,
    units: uParsed,
    totalUnits
  };
}

export function validateBatchCartonUnitQuantities(
  items: Array<{
    productId: string | number;
    cartons: unknown;
    units: unknown;
    unitsPerCarton: number;
    productName?: string;
  }>
): {
  valid: boolean;
  error?: string;
  validatedItems: Array<{
    productId: string | number;
    cartons: number;
    units: number;
    totalUnits: number;
  }>;
} {
  const validatedItems: Array<{
    productId: string | number;
    cartons: number;
    units: number;
    totalUnits: number;
  }> = [];

  for (const item of items) {
    const res = validateCartonUnitQuantity(
      item.cartons,
      item.units,
      item.unitsPerCarton,
      item.productName
    );
    if (!res.valid) {
      return {
        valid: false,
        error: res.error,
        validatedItems: []
      };
    }
    validatedItems.push({
      productId: item.productId,
      cartons: res.cartons,
      units: res.units,
      totalUnits: res.totalUnits
    });
  }

  return {
    valid: true,
    validatedItems
  };
}
