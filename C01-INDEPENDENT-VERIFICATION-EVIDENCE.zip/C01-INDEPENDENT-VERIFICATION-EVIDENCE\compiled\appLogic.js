// Generated appLogic.js for browser testing
import {
  restoreFromVerifiedBackup,
  verifyBackupPayload,
  computeSha256,
  runPostUpdateVerification,
  EXPECTED_STORES,
  BACKUP_FORMAT_VERSION,
  SCHEMA_VERSION,
  DB_VERSION,
  PROTECTED_SECURITY_FIELDS,
  validateRelationalIntegrity
} from "./safeUpdate.js";

export {
  EXPECTED_STORES,
  BACKUP_FORMAT_VERSION,
  SCHEMA_VERSION,
  DB_VERSION,
  PROTECTED_SECURITY_FIELDS,
  validateRelationalIntegrity
};

export let currentDB = null;
export function setDB(db) { currentDB = db; }
export async function openDB() { return currentDB; }

export const auditLogs = [];
export async function writeAuditLog(action, details) {
  auditLogs.push({ timestamp: Date.now(), action, details });
}

export async function getSettings() {
  const db = await openDB();
  return new Promise((resolve) => {
    try {
      const req = db.transaction("settings", "readonly").objectStore("settings").get("app");
      req.onsuccess = () => resolve(req.result ? (req.result.value || req.result) : null);
      req.onerror = () => resolve(null);
    } catch (_) { resolve(null); }
  });
}

const SEED_PRODUCTS = [
  {code:"3016",productCode:"3016",name:"قشطة لاندى*12",cartonPrice:135,upc:12,unitsPerCarton:12,cat:"قشطة",itemId:176},
  {code:"3025",productCode:"3025",name:"لبن جهينه بخيره 500جرام*24",cartonPrice:550,upc:24,unitsPerCarton:24,cat:"حليب",itemId:185},
  {code:"6010",productCode:"6010",name:"زبادوه جهينه صغير*24",cartonPrice:414,upc:24,unitsPerCarton:24,cat:"زبادي",itemId:235},
  {code:"6011",productCode:"6011",name:"زبادوه جهينه كبير*12",cartonPrice:360,upc:12,unitsPerCarton:12,cat:"زبادي",itemId:236},
  {code:"6008",productCode:"6008",name:"رايب صغير جهينه*24",cartonPrice:414,upc:24,unitsPerCarton:24,cat:"زبادي",itemId:237},
  {code:"6009",productCode:"6009",name:"رايب كبير جهينه*12",cartonPrice:360,upc:12,unitsPerCarton:12,cat:"زبادي",itemId:238},
  {code:"6018",productCode:"6018",name:"زبادى جهينة لايت 75جم وفر 2ج*48",cartonPrice:254.4,upc:48,unitsPerCarton:48,cat:"زبادي",itemId:255},
  {code:"3026",productCode:"3026",name:"عصير بخيرة 200مل*27",cartonPrice:165,upc:27,unitsPerCarton:27,cat:"عصير",itemId:259},
  {code:"6021",productCode:"6021",name:"زبادى جهينه طبيعى75جرام وفر2ج*48",cartonPrice:254.4,upc:48,unitsPerCarton:48,cat:"زبادي",itemId:262},
  {code:"6023",productCode:"6023",name:"زبادى جهينه سكروفر2ج*48",cartonPrice:254.4,upc:48,unitsPerCarton:48,cat:"زبادي",itemId:263},
  {code:"6024",productCode:"6024",name:"زبادى جهينه180جرام وفر 2ج*24",cartonPrice:360,upc:24,unitsPerCarton:24,cat:"زبادي",itemId:268},
  {code:"6031",productCode:"6031",name:"زبادى جهينه1ك*12",cartonPrice:1050,upc:12,unitsPerCarton:12,cat:"زبادي",itemId:269},
  {code:"6022",productCode:"6022",name:"زبادى جهينه فراولة 75ج وفر2ج*48",cartonPrice:254.4,upc:48,unitsPerCarton:48,cat:"زبادي",itemId:270},
  {code:"3039",productCode:"3039",name:"عصير جهينه 235مم*27",cartonPrice:243,upc:27,unitsPerCarton:27,cat:"عصير",itemId:294},
  {code:"3037",productCode:"3037",name:"عصير بخيره لتر*12",cartonPrice:360,upc:12,unitsPerCarton:12,cat:"عصير",itemId:298},
  {code:"6030",productCode:"6030",name:"زبادى جهينه 1/2كيلو*12",cartonPrice:555,upc:12,unitsPerCarton:12,cat:"زبادي",itemId:304},
  {code:"6037",productCode:"6037",name:"زبادي جهينة ستيرد 105جم 5+1*48",cartonPrice:552,upc:48,unitsPerCarton:48,cat:"زبادي",itemId:306},
  {code:"3034",productCode:"3034",name:"جهينه مكس*27",cartonPrice:365,upc:27,unitsPerCarton:27,cat:"حليب",itemId:332},
  {code:"3045",productCode:"3045",name:"قشطة 500جرام*8",cartonPrice:360,upc:8,unitsPerCarton:8,cat:"قشطة",itemId:336},
  {code:"9090",productCode:"9090",name:"زبادى دانون طبيعى*48",cartonPrice:254.4,upc:48,unitsPerCarton:48,cat:"زبادي",itemId:337},
  {code:"9091",productCode:"9091",name:"زبادى دانون فروله*48",cartonPrice:254.4,upc:48,unitsPerCarton:48,cat:"زبادي",itemId:338},
  {code:"9080",productCode:"9080",name:"شيكولاتة دانت*72",cartonPrice:480,upc:72,unitsPerCarton:72,cat:"زبادي",itemId:339},
  {code:"6016",productCode:"6016",name:"زبادى جهينه عرض 3+1 105*48",cartonPrice:408,upc:48,unitsPerCarton:48,cat:"زبادي",itemId:366},
  {code:"6029",productCode:"6029",name:"زبادى جهينه عرض 5+1*48",cartonPrice:456,upc:48,unitsPerCarton:48,cat:"زبادي",itemId:368},
  {code:"6047",productCode:"6047",name:"زبادي جهينة فاكهة قطع 105جم*48",cartonPrice:580,upc:48,unitsPerCarton:48,cat:"زبادي",itemId:369},
  {code:"9062",productCode:"9062",name:"زبادى المراعى مشكل*48",cartonPrice:210,upc:48,unitsPerCarton:48,cat:"زبادي",itemId:373},
  {code:"9092",productCode:"9092",name:"زبادى دانون البركة*48",cartonPrice:210,upc:48,unitsPerCarton:48,cat:"زبادي",itemId:374},
  {code:"5550",productCode:"5550",name:"لانشون جولدين بيف *6",cartonPrice:1980,upc:6,unitsPerCarton:6,cat:"لانشون",itemId:385},
  {code:"5552",productCode:"5552",name:"لانشون صلاح وعبدالفتاح رودى 400جم*18",cartonPrice:475,upc:18,unitsPerCarton:18,cat:"لانشون",itemId:387},
  {code:"5553",productCode:"5553",name:"لانشون صلاح 200جم*36",cartonPrice:486,upc:36,unitsPerCarton:36,cat:"لانشون",itemId:392},
  {code:"5554",productCode:"5554",name:"لانشون جريل5ك*4",cartonPrice:1500,upc:4,unitsPerCarton:4,cat:"لانشون",itemId:393},
  {code:"5555",productCode:"5555",name:"لانشون اوجينال3ك*6",cartonPrice:1830,upc:6,unitsPerCarton:6,cat:"لانشون",itemId:395},
  {code:"5556",productCode:"5556",name:"لانشون الشيف3ك*6",cartonPrice:1350,upc:6,unitsPerCarton:6,cat:"لانشون",itemId:411},
  {code:"5557",productCode:"5557",name:"لانشون تربيانكو 3ك*6",cartonPrice:2010,upc:6,unitsPerCarton:6,cat:"لانشون",itemId:412},
  {code:"5558",productCode:"5558",name:"لانشون قنجارى 3ك*6",cartonPrice:1530,upc:6,unitsPerCarton:6,cat:"لانشون",itemId:414},
  {code:"5559",productCode:"5559",name:"لانشون قنجارى بيف 3ك*6",cartonPrice:1200,upc:6,unitsPerCarton:6,cat:"لانشون",itemId:422},
  {code:"5560",productCode:"5560",name:"لانشون فليتو 3ك *6",cartonPrice:1800,upc:6,unitsPerCarton:6,cat:"لانشون",itemId:430},
  {code:"5572",productCode:"5572",name:"لانشون صلاح وعبدالفتاح 400*36",cartonPrice:990,upc:36,unitsPerCarton:36,cat:"لانشون",itemId:440},
  {code:"4428",productCode:"4428",name:"قشطة فارم ميلك*12",cartonPrice:110,upc:12,unitsPerCarton:12,cat:"قشطة",itemId:443},
  {code:"5575",productCode:"5575",name:"لانشون صلاح وعبدالفتاح بيف*6",cartonPrice:1200,upc:6,unitsPerCarton:6,cat:"لانشون",itemId:452},
  {code:"4429",productCode:"4429",name:"لاشوباك قشطة يوسي*12",cartonPrice:135,upc:12,unitsPerCarton:12,cat:"قشطة",itemId:455},
  {code:"9095",productCode:"9095",name:"زبادي دانون ط 180جم *12",cartonPrice:132,upc:12,unitsPerCarton:12,cat:"زبادي",itemId:456},
  {code:"9096",productCode:"9096",name:"دانون مشروب صغير *24",cartonPrice:414,upc:24,unitsPerCarton:24,cat:"زبادي",itemId:457},
  {code:"5577",productCode:"5577",name:"لانشون الوردة 3ك*6",cartonPrice:1200,upc:6,unitsPerCarton:6,cat:"لانشون",itemId:461},
  {code:"3049",productCode:"3049",name:"عصير بيور235*27",cartonPrice:505,upc:27,unitsPerCarton:27,cat:"عصير",itemId:464},
  {code:"3048",productCode:"3048",name:"حليب جهينه لتر كامل الدسم *12",cartonPrice:642,upc:12,unitsPerCarton:12,cat:"حليب",itemId:466},
  {code:"3047",productCode:"3047",name:"عصير جهينه لتر *12",cartonPrice:426,upc:12,unitsPerCarton:12,cat:"عصير",itemId:467},
  {code:"3044",productCode:"3044",name:"حليب جهينة سادة 200مل*27",cartonPrice:365,upc:27,unitsPerCarton:27,cat:"حليب",itemId:470},
  {code:"3068",productCode:"3068",name:"حليب بخيره كامل الدسم 1ك*12",cartonPrice:505,upc:12,unitsPerCarton:12,cat:"حليب",itemId:474},
  {code:"5100",productCode:"5100",name:"حلاوة حمزة 100جم *36",cartonPrice:333,upc:36,unitsPerCarton:36,cat:"حلاوة",itemId:480},
  {code:"5200",productCode:"5200",name:"حلاوة حمزة 200جم  *20",cartonPrice:360,upc:20,unitsPerCarton:20,cat:"حلاوة",itemId:481},
  {code:"011",productCode:"011",name:"لبن كامل الدسم بودر سلسلة 25جم *15",cartonPrice:1155,upc:15,unitsPerCarton:15,cat:"بودر",itemId:482},
  {code:"012",productCode:"012",name:"لبن محلي مشكل 12جم*24",cartonPrice:780,upc:24,unitsPerCarton:24,cat:"بودر",itemId:483},
  {code:"013",productCode:"013",name:"كريمة خام بودر45جم *20",cartonPrice:1800,upc:20,unitsPerCarton:20,cat:"بودر",itemId:484},
  {code:"014",productCode:"014",name:"عصير بودر أصناف 7جم*24",cartonPrice:288,upc:24,unitsPerCarton:24,cat:"بودر",itemId:485},
  {code:"015",productCode:"015",name:"عصير بودر أصناف 25جم*24",cartonPrice:980,upc:24,unitsPerCarton:24,cat:"بودر",itemId:486},
  {code:"016",productCode:"016",name:"لاتيريا قهوة 2*1 *24",cartonPrice:1320,upc:24,unitsPerCarton:24,cat:"بودر",itemId:487},
  {code:"017",productCode:"017",name:"لاتيريا قهوة 3*1 *24",cartonPrice:1044,upc:24,unitsPerCarton:24,cat:"بودر",itemId:488},
  {code:"018",productCode:"018",name:"لاتريا سحلب أصناف 100جم *30",cartonPrice:390,upc:30,unitsPerCarton:30,cat:"بودر",itemId:489},
  {code:"6048",productCode:"6048",name:"زبادى بودنج شيكولاته 60جم*48",cartonPrice:276,upc:48,unitsPerCarton:48,cat:"زبادي",itemId:497},
  {code:"001",productCode:"001",name:"زبادى يونانى فواكه 180جم *24",cartonPrice:1080,upc:24,unitsPerCarton:24,cat:"زبادي",itemId:498},
  {code:"002",productCode:"002",name:"زبادى جهينه يونانى سادة 180جم*24",cartonPrice:990,upc:24,unitsPerCarton:24,cat:"زبادي",itemId:499},
  {code:"022",productCode:"022",name:"لاتريا سحلب علب بلاستيك 250جم*10",cartonPrice:300,upc:10,unitsPerCarton:10,cat:"بودر",itemId:502},
  {code:"7777",productCode:"7777",name:"جبنه لوكا 250جم *27",cartonPrice:350,upc:27,unitsPerCarton:27,cat:"جبنة",itemId:503},
  {code:"023",productCode:"023",name:"لاتريا سوبيا 450جم*10",cartonPrice:600,upc:10,unitsPerCarton:10,cat:"بودر",itemId:504},
  {code:"9065",productCode:"9065",name:"زبادى قطع المراعى 70جم*48",cartonPrice:264,upc:48,unitsPerCarton:48,cat:"زبادي",itemId:506},
  {code:"9064",productCode:"9064",name:"مشروب صغير المراعى *12",cartonPrice:183,upc:12,unitsPerCarton:12,cat:"زبادي",itemId:507},
  {code:"024",productCode:"024",name:"لاتيريا عصير بودر 500جم برطمان *8",cartonPrice:400,upc:8,unitsPerCarton:8,cat:"بودر",itemId:508},
  {code:"5588",productCode:"5588",name:"لانشون فرصه 3ك*8",cartonPrice:1520,upc:8,unitsPerCarton:8,cat:"لانشون",itemId:509},
  {code:"5101",productCode:"5101",name:"حلاوة حمزة 100جم*24",cartonPrice:222,upc:24,unitsPerCarton:24,cat:"حلاوة",itemId:512},
  {code:"5201",productCode:"5201",name:"حلاوة حمزة 200جم*18",cartonPrice:324,upc:18,unitsPerCarton:18,cat:"حلاوة",itemId:514},
  {code:"025",productCode:"025",name:"لاتريا عصير بودر مركز 10جم*24",cartonPrice:1008,upc:24,unitsPerCarton:24,cat:"بودر",itemId:515},
  {code:"026",productCode:"026",name:"لاتريا جيلي بودر 70جم*72",cartonPrice:864,upc:72,unitsPerCarton:72,cat:"بودر",itemId:516},
  {code:"9066",productCode:"9066",name:"عصير المراعي200مل*27",cartonPrice:200,upc:27,unitsPerCarton:27,cat:"عصير",itemId:517},
  {code:"5589",productCode:"5589",name:"لانشون نيفا 3كيلو*6",cartonPrice:1620,upc:6,unitsPerCarton:6,cat:"لانشون",itemId:518},
  {code:"5534",productCode:"5534",name:"لانشون رودي 300*40",cartonPrice:800,upc:40,unitsPerCarton:40,cat:"لانشون",itemId:519},
  {code:"5202",productCode:"5202",name:"حلاوة حمزة 200جم*15",cartonPrice:277.5,upc:15,unitsPerCarton:15,cat:"حلاوة",itemId:520},
  {code:"7101",productCode:"7101",name:"عصير تشاو تتراباك مشكل200مل*27",cartonPrice:117,upc:27,unitsPerCarton:27,cat:"عصير",itemId:521},
  {code:"7102",productCode:"7102",name:"عصير إيجي لاند تتراباك مشكل 200مل*27",cartonPrice:121,upc:27,unitsPerCarton:27,cat:"عصير",itemId:522},
  {code:"7103",productCode:"7103",name:"عصير إيجي لاند زجاج 250مل*24",cartonPrice:335,upc:24,unitsPerCarton:24,cat:"عصير",itemId:523},
  {code:"7104",productCode:"7104",name:"صلصة ايجي لاند 300جم*24",cartonPrice:335,upc:24,unitsPerCarton:24,cat:"أخرى",itemId:524},
  {code:"3139",productCode:"3139",name:"عصير بيور 1 لتر*12",cartonPrice:780,upc:12,unitsPerCarton:12,cat:"عصير",itemId:525},
  {code:"5590",productCode:"5590",name:"لانشون وصاية 3ك*6",cartonPrice:1620,upc:6,unitsPerCarton:6,cat:"لانشون",itemId:526},
  {code:"5102",productCode:"5102",name:"حلاوة البستان 100جم*30",cartonPrice:277.5,upc:30,unitsPerCarton:30,cat:"حلاوة",itemId:527},
  {code:"60081",productCode:"60081",name:"رايب سوبيا مانجو200مل*24",cartonPrice:432,upc:24,unitsPerCarton:24,cat:"زبادي",itemId:529},
  {code:"6101",productCode:"6101",name:"كريمة طهي 200مل*27",cartonPrice:1755,upc:27,unitsPerCarton:27,cat:"حليب",itemId:530},
  {code:"55551",productCode:"55551",name:"لانشون أورجينال1ك*18",cartonPrice:1710,upc:18,unitsPerCarton:18,cat:"لانشون",itemId:531},
  {code:"3069",productCode:"3069",name:"حليب جهينة لتر ونصف*8",cartonPrice:560,upc:8,unitsPerCarton:8,cat:"حليب",itemId:532},
  {code:"14001",productCode:"14001",name:"لاشوباك فيتا 250جم*27",cartonPrice:380,upc:27,unitsPerCarton:27,cat:"جبنة",itemId:533},
  {code:"14002",productCode:"14002",name:"لاشوباك فيتا 80جم*50",cartonPrice:225,upc:50,unitsPerCarton:50,cat:"جبنة",itemId:534},
  {code:"14003",productCode:"14003",name:"لاشوباك مثلثات فردي*36",cartonPrice:350,upc:36,unitsPerCarton:36,cat:"جبنة",itemId:535},
  {code:"14004",productCode:"14004",name:"لاشوباك كيري 500جم*12",cartonPrice:515,upc:12,unitsPerCarton:12,cat:"جبنة",itemId:536},
  {code:"14005",productCode:"14005",name:"لاشوباك كيري 1ك*12",cartonPrice:900,upc:12,unitsPerCarton:12,cat:"جبنة",itemId:537},
  {code:"14006",productCode:"14006",name:"لاشوباك قريش 500جم*12",cartonPrice:300,upc:12,unitsPerCarton:12,cat:"جبنة",itemId:538},
  {code:"14007",productCode:"14007",name:"لاشوباك صلصة 500جم*12",cartonPrice:186,upc:12,unitsPerCarton:12,cat:"أخرى",itemId:539},
  {code:"14008",productCode:"14008",name:"لاشوباك مربى زجاج*12",cartonPrice:280,upc:12,unitsPerCarton:12,cat:"أخرى",itemId:540},
  {code:"14009",productCode:"14009",name:"لاشوباك مربي جار 5ك",cartonPrice:225,upc:1,unitsPerCarton:1,cat:"أخرى",itemId:541},
  {code:"60091",productCode:"60091",name:"رايب جهينة سوبيا مانجو 400مل*12",cartonPrice:360,upc:12,unitsPerCarton:12,cat:"زبادي",itemId:542},
  {code:"5593",productCode:"5593",name:"لانشون سوبر 3كيلو*6",cartonPrice:1440,upc:6,unitsPerCarton:6,cat:"لانشون",itemId:543},
  {code:"7105",productCode:"7105",name:"حليب محلى إيجي لاند*27",cartonPrice:270,upc:27,unitsPerCarton:27,cat:"حليب",itemId:544},
  {code:"5535",productCode:"5535",name:"لانشون صلاح بيف 200جم**60",cartonPrice:780,upc:60,unitsPerCarton:60,cat:"لانشون",itemId:545},
  {code:"5536",productCode:"5536",name:"لانشون صلاح بيف 400جم*36",cartonPrice:990,upc:36,unitsPerCarton:36,cat:"لانشون",itemId:546},
  {code:"6102",productCode:"6102",name:"جهينة رايب 1لتر*12",cartonPrice:612,upc:12,unitsPerCarton:12,cat:"زبادي",itemId:547},
  {code:"14010",productCode:"14010",name:"لاشوباك صلصة ظرف*4",cartonPrice:220,upc:4,unitsPerCarton:4,cat:"أخرى",itemId:548},
  {code:"14011",productCode:"14011",name:"لاشوباك صلصة 3ك*4",cartonPrice:460,upc:4,unitsPerCarton:4,cat:"أخرى",itemId:549},
  {code:"14012",productCode:"14012",name:"لاشوباك صلصة 400جم صفيح*12",cartonPrice:252,upc:12,unitsPerCarton:12,cat:"أخرى",itemId:550},
  {code:"9093",productCode:"9093",name:"زبادي دانون سكر*48",cartonPrice:254.4,upc:48,unitsPerCarton:48,cat:"زبادي",itemId:551},
  {code:"6103",productCode:"6103",name:"VAMOS-مشروب شعير 300مل*24",cartonPrice:444,upc:24,unitsPerCarton:24,cat:"مشروب شعير وطاقة",itemId:552},
  {code:"6049",productCode:"6049",name:"زبادي بودنج شيكولاتة 100جم*48",cartonPrice:492,upc:48,unitsPerCarton:48,cat:"زبادي",itemId:553},
  {code:"19001",productCode:"19001",name:"زبادي دانون طبيعي75جم*72",cartonPrice:381.6,upc:72,unitsPerCarton:72,cat:"زبادي",itemId:554},
  {code:"19002",productCode:"19002",name:"زبادي دانون فراولة75جم*72",cartonPrice:381.6,upc:72,unitsPerCarton:72,cat:"زبادي",itemId:555},
  {code:"19003",productCode:"19003",name:"زبادي دانون سكر75جم*72",cartonPrice:381.6,upc:72,unitsPerCarton:72,cat:"زبادي",itemId:556},
  {code:"19047",productCode:"19047",name:"زبادي دانون قطع120جم*24",cartonPrice:325,upc:24,unitsPerCarton:24,cat:"زبادي",itemId:557},
  {code:"19034",productCode:"19034",name:"دانون حليب محلى*27",cartonPrice:310,upc:27,unitsPerCarton:27,cat:"حليب",itemId:558},
  {code:"14013",productCode:"14013",name:"لاشوباك مربى 1ك*6",cartonPrice:264,upc:6,unitsPerCarton:6,cat:"أخرى",itemId:559},
  {code:"14014",productCode:"14014",name:"لاشوباك مش 500جم*12",cartonPrice:240,upc:12,unitsPerCarton:12,cat:"جبنة",itemId:560},
  {code:"6106",productCode:"6106",name:"جهينة لبنة 250جم*18",cartonPrice:1675,upc:18,unitsPerCarton:18,cat:"أخرى",itemId:561},
  {code:"5594",productCode:"5594",name:"لانشون صلاح بلس 5ك*4",cartonPrice:2400,upc:4,unitsPerCarton:4,cat:"لانشون",itemId:562},
  {code:"14015",productCode:"14015",name:"لاشوباك جار 8ك*1",cartonPrice:680,upc:1,unitsPerCarton:1,cat:"جبنة",itemId:563},
  {code:"14016",productCode:"14016",name:"لاشوباك جار 10ك*1",cartonPrice:850,upc:1,unitsPerCarton:1,cat:"جبنة",itemId:564},
  {code:"14017",productCode:"14017",name:"لاشوباك تحابيش3ك*1",cartonPrice:120,upc:1,unitsPerCarton:1,cat:"جبنة",itemId:565},
  {code:"14018",productCode:"14018",name:"لاشوباك كاتشب ظرف*500",cartonPrice:150,upc:500,unitsPerCarton:500,cat:"أخرى",itemId:566},
  {code:"14019",productCode:"14019",name:"لاشوباك كيري 3ك*1",cartonPrice:220,upc:1,unitsPerCarton:1,cat:"جبنة",itemId:567},
  {code:"14020",productCode:"14020",name:"لاشوباك جبن شيدر بلوك تقطيع 400جم*12",cartonPrice:360,upc:12,unitsPerCarton:12,cat:"جبنة",itemId:568},
  {code:"14021",productCode:"14021",name:"لاشوباك كاتشب 1كيلو*6",cartonPrice:210,upc:6,unitsPerCarton:6,cat:"أخرى",itemId:569},
  {code:"7106",productCode:"7106",name:"عصير دادو مشكل 200مل*27",cartonPrice:121,upc:27,unitsPerCarton:27,cat:"عصير",itemId:570},
  {code:"5592",productCode:"5592",name:"لانشون المصرية 3ك*6",cartonPrice:1500,upc:6,unitsPerCarton:6,cat:"لانشون",itemId:571},
  {code:"033",productCode:"033",name:"لاتريا كريمة طعوم بودر 45جم *20",cartonPrice:2000,upc:20,unitsPerCarton:20,cat:"بودر",itemId:572},
  {code:"027",productCode:"027",name:"لاتريا توابل بطاطس بودر 5كجم*1",cartonPrice:600,upc:1,unitsPerCarton:1,cat:"بودر",itemId:573},
  {code:"028",productCode:"028",name:"لاتريا 7بهارات 40جم*12",cartonPrice:960,upc:12,unitsPerCarton:12,cat:"بودر",itemId:574},
  {code:"029",productCode:"029",name:"لاتريا مرقة دجاج فورية 60جم*30",cartonPrice:540,upc:30,unitsPerCarton:30,cat:"بودر",itemId:575},
  {code:"030",productCode:"030",name:"لاتريا خلطة فيجيتار(حار+بارد) 40جم*17",cartonPrice:765,upc:17,unitsPerCarton:17,cat:"بودر",itemId:576},
  {code:"031",productCode:"031",name:"لاتريا خلطة بشامل 70جم*12",cartonPrice:684,upc:12,unitsPerCarton:12,cat:"بودر",itemId:577},
  {code:"6104",productCode:"6104",name:"Gorilla  مشروب طاقة 250مل*24",cartonPrice:480,upc:24,unitsPerCarton:24,cat:"مشروب شعير وطاقة",itemId:578},
  {code:"15001",productCode:"15001",name:"تسالي لب القائد*6",cartonPrice:600,upc:6,unitsPerCarton:6,cat:"أخرى",itemId:579},
  {code:"6105",productCode:"6105",name:"Gorilla- مشروب طاقة 500مل*12",cartonPrice:420,upc:12,unitsPerCarton:12,cat:"مشروب شعير وطاقة",itemId:580},
  {code:"14118",productCode:"14118",name:"لاشوباك كاتشب ظرف*1000",cartonPrice:300,upc:1000,unitsPerCarton:1000,cat:"أخرى",itemId:581},
  {code:"5595",productCode:"5595",name:"لانشون نيفا  1كيلو*20",cartonPrice:2000,upc:20,unitsPerCarton:20,cat:"لانشون",itemId:582},
  {code:"003",productCode:"003",name:"كليوباترا عرض كاتشب 1كيلو*6",cartonPrice:375,upc:6,unitsPerCarton:6,cat:"أخرى",itemId:583},
  {code:"004",productCode:"004",name:"كليوباترا ماء ورد عرض 2+1 *8",cartonPrice:200,upc:8,unitsPerCarton:8,cat:"أخرى",itemId:584},
  {code:"005",productCode:"005",name:"كليوباترا صوص عرض 3+1 *6",cartonPrice:540,upc:6,unitsPerCarton:6,cat:"أخرى",itemId:585},
  {code:"6038",productCode:"6038",name:"زبادي جهينة ستيرد 105جم 4+2 *48",cartonPrice:360,upc:48,unitsPerCarton:48,cat:"زبادي",itemId:586}
];

async function initProductionCatalog() {
  const s = await getSettings();
  if (s && s.productionCatalogInitialized) return;

  const db = await openDB();
  try {
    await new Promise((resolve, reject) => {
      // ALL operational stores that must be empty before allowing catalog reset.
      // This list must stay in sync with hasOperationalData() — both check the
      // same set of stores so there is a single source of truth for "what
      // constitutes operational data that blocks re-initialization".
      const requiredStores = [
        "products",
        "settings",
        "auditLog",
        "days",           // added: day records block re-initialization
        "dayReopenLogs",  // added: reopen audit records block re-initialization
        "openingStock",
        "loads",
        "additions",
        "unloads",
        "damages",
        "discounts",      // added: discount records block re-initialization
        "closingStock",
        "dayPriceSnapshot"
      ];
      const tx = db.transaction(requiredStores, "readwrite");

      let settled = false;
      let lastError = null;

      function fail(err) {
        if (!lastError && err) lastError = err;
        if (!settled) {
          settled = true;
          try { tx.abort(); } catch (_) {}
          reject(lastError || new Error("[ProductionCatalog] Transaction failed"));
        }
      }

      tx.onabort = () => {
        fail(tx.error || lastError || new Error("[ProductionCatalog] Transaction aborted"));
      };

      tx.onerror = () => {
        fail(tx.error || lastError || new Error("[ProductionCatalog] Transaction error"));
      };

      // In-transaction settings read to prevent race conditions during cold start
      const setStore = tx.objectStore("settings");
      const settingsReq = setStore.get("app");

      // In-transaction counts for all protected child stores.
      // Any non-zero count blocks products.clear() and catalog reset.
      // Matches the store list in hasOperationalData() exactly.
      //
      // auditLog is included because hasOperationalData() treats it as
      // operational data. A pre-existing auditLog entry means some event
      // already occurred on this device (even if products/days are empty),
      // so destructive catalog reset must be blocked. initProductionCatalog
      // itself writes one auditLog entry on success — but that write only
      // happens inside the same transaction AFTER the guard checks pass,
      // so there is no self-blocking risk.
      const childStores = [
        "days",           // any day record → real operational history exists
        "dayReopenLogs",  // any reopen log → day was used and re-opened
        "auditLog",       // any prior audit entry → prior activity on device
        "openingStock",
        "loads",
        "additions",
        "unloads",
        "damages",
        "discounts",      // any discount record → transactions were processed
        "closingStock",
        "dayPriceSnapshot"
      ];

      let pendingCounts = childStores.length;
      let settingsLoaded = false;
      let hasHistory = false;

      function evaluateAndExecute() {
        if (settled || pendingCounts > 0 || !settingsLoaded) return;

        // Verify inside the atomic lock that no racing transaction already initialized
        const currentSettingsRec = settingsReq.result;
        const currentSettings = currentSettingsRec ? (currentSettingsRec.value || currentSettingsRec) : null;
        if (currentSettings && currentSettings.productionCatalogInitialized) {
          return;
        }

        // If any transaction history exists in any child store, strictly skip destructive clear
        if (hasHistory) {
          console.warn("[ProductionCatalog] Existing transaction history detected — skipping destructive catalog reset.");
          return;
        }

        // All 11 protected child stores are strictly empty and catalog is uninitialized.
        // Queue products.clear() synchronously within the transaction callback:
        const prodStore = tx.objectStore("products");
        const clearReq = prodStore.clear();

        clearReq.onerror = () => {
          fail(clearReq.error || new Error("[ProductionCatalog] Failed to clear products store"));
        };

        clearReq.onsuccess = () => {
          if (settled) return;
          const now = Date.now();
          for (const p of SEED_PRODUCTS) {
            const addReq = prodStore.add({
              code: p.code,
              productCode: p.productCode || p.code,
              name: p.name,
              cat: p.cat,
              cartonPrice: p.cartonPrice,
              unitsPerCarton: p.unitsPerCarton,
              unitPrice: parseFloat((p.cartonPrice / p.unitsPerCarton).toFixed(4)),
              itemId: p.itemId,
              status: "active",
              createdAt: now,
              updatedAt: now,
            });
            addReq.onerror = () => {
              fail(addReq.error || new Error(`[ProductionCatalog] Failed to add product ${p.code}`));
            };
          }

          const baseSettings = currentSettings || s || {};
          const putSetReq = setStore.put({
            key: "app",
            value: { ...baseSettings, productionCatalogInitialized: true, productRecoveryDone: true }
          });
          putSetReq.onerror = () => {
            fail(putSetReq.error || new Error("[ProductionCatalog] Failed to save settings"));
          };

          const auditStore = tx.objectStore("auditLog");
          const addAuditReq = auditStore.add({
            timestamp: now,
            action: "PRODUCTION_CATALOG_INITIALIZATION",
            details: JSON.stringify({
              productsCount: SEED_PRODUCTS.length,
              date: new Date(now).toISOString(),
              note: "Authoritative 142-product company catalog initialized"
            })
          });
          addAuditReq.onerror = () => {
            fail(addAuditReq.error || new Error("[ProductionCatalog] Failed to write audit log"));
          };
        };
      }

      settingsReq.onsuccess = () => {
        settingsLoaded = true;
        evaluateAndExecute();
      };
      settingsReq.onerror = () => {
        fail(settingsReq.error || new Error("[ProductionCatalog] Failed to read settings"));
      };

      for (const stName of childStores) {
        const countReq = tx.objectStore(stName).count();
        countReq.onsuccess = () => {
          if (countReq.result > 0) {
            hasHistory = true;
          }
          pendingCounts--;
          evaluateAndExecute();
        };
        countReq.onerror = () => {
          fail(countReq.error || new Error(`[ProductionCatalog] Failed to count records in ${stName}`));
        };
      }

      tx.oncomplete = () => {
        if (settled) return;
        settled = true;
        if (!hasHistory) {
          console.log(`[ProductionCatalog] Initialized ${SEED_PRODUCTS.length} production products.`);
        }
        resolve();
      };
    });
  } catch (err) {
    console.error("[ProductionCatalog] Error initializing catalog:", err);
    throw err;
  }
}



function isValidCalendarDate(dateStr) {
  if (typeof dateStr !== "string" || !/^\d{4}-\d{2}-\d{2}$/.test(dateStr)) return false;
  const [y, m, d] = dateStr.split("-").map(Number);
  if (m < 1 || m > 12 || d < 1 || d > 31) return false;
  const dt = new Date(Date.UTC(y, m - 1, d));
  return dt.getUTCFullYear() === y && (dt.getUTCMonth() + 1) === m && dt.getUTCDate() === d;
}



async function performRestore(backup) {
  if (!backup.data || !backup.exportedAt)
    throw new Error("ملف غير صالح — يجب أن يحتوي على حقلي data و exportedAt");

  if (backup.backupFormat && !backup.backupFormat.startsWith("PLMS-BACKUP-")) {
    throw new Error(
      `صيغة الملف غير معروفة: "${backup.backupFormat}".\n` +
      "هذا الملف لم يُنشأ بواسطة تطبيق باتريا لاكتيس."
    );
  }
  const isV2 = backup.backupFormat === BACKUP_FORMAT_VERSION;
  // R32-02: Strict Schema Version Validation across all backup formats
  if (backup.schemaVersion !== undefined) {
    if (typeof backup.schemaVersion !== "string" || !/^\d+\.\d+(\.\d+)?$/.test(backup.schemaVersion)) {
      throw new Error(`صيغة إصدار المخطط غير صالحة في ملف النسخة الاحتياطية: "${backup.schemaVersion}"`);
    }
  }
  const isLegacyBackup = !backup.schemaVersion;
  const fileSchema = isLegacyBackup ? "legacy" : backup.schemaVersion;
  const appSchema = SCHEMA_VERSION;

  // Check integrity checksum if v2 (SEC-02: mandatory, valid SHA-256 hex checksum)
  if (isV2) {
    const checksum = backup.integrity?.checksum;
    if (!checksum || typeof checksum !== "string" || !/^[0-9a-f]{64}$/i.test(checksum)) {
      throw new Error("فشل التحقق: نسخة v2 تتطلب بصمة رقمية صالحة (SHA-256 hex checksum).");
    }
    const canonical = JSON.stringify(backup.data);
    const computed = await computeSha256(canonical);
    if (computed.toLowerCase() !== checksum.toLowerCase()) {
      throw new Error("فشل التحقق من البصمة الرقمية للنسخة الاحتياطية. الملف تالف أو تم تعديله.");
    }
  }

  let fileMaj = 0, fileMin = 0, filePatch = 0;
  if (!isLegacyBackup) {
    const parts = fileSchema.split(".").map(Number);
    fileMaj = parts[0] || 0;
    fileMin = parts[1] || 0;
    filePatch = parts[2] || 0;
  }
  const appParts = appSchema.split(".").map(Number);
  const appMaj = appParts[0] || 0;
  const appMin = appParts[1] || 0;
  const appPatch = appParts[2] || 0;

  const isOlderSchema = isLegacyBackup || fileMaj < appMaj || (fileMaj === appMaj && fileMin < appMin) || (fileMaj === appMaj && fileMin === appMin && filePatch < appPatch);
  const isNewerSchema = !isLegacyBackup && (fileMaj > appMaj || (fileMaj === appMaj && fileMin > appMin) || (fileMaj === appMaj && fileMin === appMin && filePatch > appPatch));

  if (isNewerSchema) {
    throw new Error(
      `إصدار ملف الـ Backup (${fileSchema}) أحدث من إصدار التطبيق (${appSchema}).\n` +
      "يجب تحديث التطبيق أولاً قبل الاستيراد."
    );
  }



  const fileDBVer = backup.databaseVersion || 1;
  if (fileDBVer > DB_VERSION) {
    throw new Error(
      `إصدار قاعدة البيانات في الملف (v${fileDBVer}) أعلى من التطبيق (v${DB_VERSION}). ` +
      "يجب تحديث التطبيق."
    );
  }

  // ── PHASE 8.3 FIX ────────────────────────────────────────────────────────────
  // For v2 backups use restoreFromVerifiedBackup which atomically clears each
  // operational store before re-inserting records, preventing leftover records
  // from a previous state remaining in the DB (the "merge instead of replace" bug).
  // Legacy / older-schema imports fall through to the dbPut loop below so that
  // the existing schema-upgrade migration path is unaffected.
  if (isV2) {
    const db = await openDB();
    const result = await restoreFromVerifiedBackup(db, backup);
    const imported = result.totalRestored;
    await writeAuditLog("BACKUP_RESTORE", {
      fileSchema, recordsImported: imported,
      driverName: backup.driverName || "غير محدد",
      exportDate: backup.exportDate || "غير محدد",
    });
    return { imported, message: `تم استيراد ${imported.toLocaleString("ar-EG")} سجل بنجاح والتحقق من سلامة البيانات ✅` };
  }

  // L-01: Legacy imports keep MERGE semantics, but all writes are atomic.
  // Validate the entire payload before starting any write transaction.
  // R31-02: Comprehensive pre-transaction schema & relational compatibility validation
  const legacyRows = {};
  const seenLegacyProductIds = new Set();
  const seenLegacyProductCodes = new Set();

  for (const storeName of EXPECTED_STORES) {
    const rows = backup.data[storeName];
    if (rows !== undefined && !Array.isArray(rows)) {
      throw new Error(`بيانات غير صالحة في ${storeName}: يجب أن تكون قائمة`);
    }
    legacyRows[storeName] = (rows || []).filter(rec => {
      if (!rec || typeof rec !== "object" || Array.isArray(rec)) {
        throw new Error(`سجل غير صالح في ${storeName}`);
      }
      if (storeName === "settings") {
        if (typeof rec.key !== "string" || !rec.key) throw new Error("مفتاح إعدادات غير صالح");
        return rec.key !== "plms_update_state" && rec.key !== "recovery_index" && !rec.key.startsWith("recovery_backup_");
      }
      if (rec.id !== undefined && (!Number.isSafeInteger(rec.id) || rec.id <= 0)) {
        throw new Error(`معرف سجل غير صالح في ${storeName}`);
      }

      // Schema validation for operational stores:
      if (storeName === "products") {
        if (typeof rec.code !== "string" || !rec.code.trim()) throw new Error("صنف ببيانات رمز غير صالحة في النسخة القديمة");
        if (rec.cartonPrice !== undefined && (!Number.isFinite(rec.cartonPrice) || rec.cartonPrice <= 0)) {
          throw new Error(`سعر كرتونة غير صالح للصنف: ${rec.code}`);
        }
        if (rec.unitsPerCarton !== undefined && (!Number.isSafeInteger(rec.unitsPerCarton) || rec.unitsPerCarton <= 0)) {
          throw new Error(`سعة كرتونة غير صالحة للصنف: ${rec.code}`);
        }
        // R32-01: Intra-backup duplicate checks
        if (rec.id !== undefined) {
          if (seenLegacyProductIds.has(rec.id)) {
            throw new Error(`معرف صنف مكرر داخل النسخة المستوردة: ${rec.id}`);
          }
          seenLegacyProductIds.add(rec.id);
        }
        const cleanCode = rec.code.trim();
        if (seenLegacyProductCodes.has(cleanCode)) {
          throw new Error(`كود صنف مكرر داخل النسخة المستوردة: "${cleanCode}"`);
        }
        seenLegacyProductCodes.add(cleanCode);
      } else if (storeName === "days") {
        // R32-05: True calendar validation
        if (!isValidCalendarDate(rec.date)) {
          throw new Error(`تاريخ غير صالح أو غير موجود تقويمياً في سجل الأيام بالنسخة القديمة: "${rec.date}"`);
        }
      } else if (storeName === "closingStock" || storeName === "openingStock") {
        if (rec.totalUnits !== undefined && (!Number.isSafeInteger(rec.totalUnits) || rec.totalUnits < 0)) {
          throw new Error(`إجمالي وحدات غير صالح في ${storeName}`);
        }
      }
      return true;
    });
  }
  // Read local device credentials, products, and days in read transactions BEFORE starting writes.
  const db = await openDB();

  // Read local products and days to validate MERGE conflicts (R32-01) and foreign key integrity (R32-07)
  const localProducts = await new Promise((res, rej) => {
    const req = db.transaction("products", "readonly").objectStore("products").getAll();
    req.onsuccess = () => res(req.result || []);
    req.onerror = () => rej(req.error);
  });
  const localDays = await new Promise((res, rej) => {
    const req = db.transaction("days", "readonly").objectStore("days").getAll();
    req.onsuccess = () => res(req.result || []);
    req.onerror = () => rej(req.error);
  });

  // R32-01: MERGE conflict check with local database
  const localById = new Map(localProducts.map(p => [p.id, p]));
  const localByCode = new Map(localProducts.map(p => [p.code?.trim(), p]));

  for (const rec of legacyRows["products"] || []) {
    const cleanCode = rec.code.trim();
    const existCode = localByCode.get(cleanCode);
    const existId = rec.id !== undefined ? localById.get(rec.id) : null;

    if (existCode && rec.id !== undefined && existCode.id !== rec.id) {
      throw new Error(`تعارض كود صنف مع قاعدة البيانات المحلية: الكود "${cleanCode}" مسجل محلياً للصنف معرف ${existCode.id}، بينما يحمل المعرف ${rec.id} في النسخة المستوردة`);
    }
    if (existId && existId.code?.trim() !== cleanCode) {
      throw new Error(`تعارض معرف صنف مع قاعدة البيانات المحلية: المعرف ${rec.id} مسجل محلياً للكود "${existId.code}"، بينما يحمل الكود "${cleanCode}" في النسخة المستوردة`);
    }
    if (rec.id === undefined && existCode) {
      throw new Error(`تعارض كود صنف مع قاعدة البيانات المحلية: الكود "${cleanCode}" موجود بالفعل محلياً بدون تحديد معرف في النسخة`);
    }
  }

  // B-01 / C-01: Strict Policy A — All-or-Nothing relational integrity validation — MERGE mode
  // Uses the resulting parent sets AFTER collision resolution (i.e., surviving records only).
  // The validateRelationalIntegrity function in MERGE mode:
  //   - Applies real collision semantics before authorizing any parent IDs
  //   - Performs explicit non-truthiness checks (null, undefined, empty string, non-safe-int)
  //   - Only records that survive the merge may authorize child relationships
  const b01Result = validateRelationalIntegrity({
    mode: "MERGE",
    incomingData: legacyRows,
    liveProducts: localProducts,
    liveDays: localDays
  });
  if (!b01Result.valid) {
    throw new Error(
      `رفض الاستعادة — خطأ في التحقق من سلامة العلاقات المرجعية (B-01 / السياسة أ — كل شيء أو لا شيء): ${b01Result.error}`
    );
  }

  // Read local device credentials in the SAME transaction as the writes.
  // A failed read aborts the transaction; foreign credentials never cross devices.
  const touched = EXPECTED_STORES.filter(name => legacyRows[name].length > 0);
  let imported = 0;
  if (touched.length) {
    imported = await new Promise((resolve, reject) => {
      // C-01 Final Closure: Include "products" and "days" in write transaction scope even if no writes
      // are made to those stores, and perform authoritative in-transaction validation under the exclusive lock.
      const tx = db.transaction([...new Set([...touched, "settings", "products", "days"])], "readwrite");
      let count = 0;
      let settled = false;
      const fail = err => { if (!settled) { settled = true; reject(err || new Error("Legacy restore aborted")); } };
      tx.onabort = () => fail(tx.error || new Error("Legacy restore aborted"));
      tx.onerror = () => { /* onabort owns the final error */ };
      tx.oncomplete = () => { if (!settled) { settled = true; resolve(count); } };

      const settingsReq = tx.objectStore("settings").get("app");
      const prodsReq = tx.objectStore("products").getAll();
      const daysReq = tx.objectStore("days").getAll();

      let settingsDone = false, prodsDone = false, daysDone = false;
      let localApp = null, liveTxProducts = null, liveTxDays = null;

      const checkAndExecute = () => {
        if (!settingsDone || !prodsDone || !daysDone) return;
        try {
          const local = localApp;
          if (!local || typeof local !== "object" || Array.isArray(local)) {
            throw new Error("تعذر قراءة إعدادات أمان الجهاز المحلي");
          }

          // C-01: Authoritative in-transaction collision validation against current live parent state
          const liveById = new Map(liveTxProducts.map(p => [p.id, p]));
          const liveByCode = new Map(liveTxProducts.map(p => [p.code?.trim(), p]));

          for (const rec of legacyRows["products"] || []) {
            const cleanCode = rec.code.trim();
            const existCode = liveByCode.get(cleanCode);
            const existId = rec.id !== undefined ? liveById.get(rec.id) : null;

            if (existCode && rec.id !== undefined && existCode.id !== rec.id) {
              throw new Error(`تعارض كود صنف مع قاعدة البيانات المحلية: الكود "${cleanCode}" مسجل محلياً للصنف معرف ${existCode.id}، بينما يحمل المعرف ${rec.id} في النسخة المستوردة`);
            }
            if (existId && existId.code?.trim() !== cleanCode) {
              throw new Error(`تعارض معرف صنف مع قاعدة البيانات المحلية: المعرف ${rec.id} مسجل محلياً للكود "${existId.code}"، بينما يحمل الكود "${cleanCode}" في النسخة المستوردة`);
            }
            if (rec.id === undefined && existCode) {
              throw new Error(`تعارض كود صنف مع قاعدة البيانات المحلية: الكود "${cleanCode}" موجود بالفعل محلياً بدون تحديد معرف في النسخة`);
            }
          }

          // C-01: Authoritative Policy A in-transaction relational integrity check
          // Guarantees child records only reference parents that actually exist under this lock
          const inTxValResult = validateRelationalIntegrity({
            mode: "MERGE",
            incomingData: legacyRows,
            liveProducts: liveTxProducts,
            liveDays: liveTxDays
          });
          if (!inTxValResult.valid) {
            throw new Error(
              `رفض الاستعادة داخل المعاملة — خطأ علاقة مرجعية (C-01 / السياسة أ): ${inTxValResult.error}`
            );
          }

          // All validations passed under exclusive lock! Now execute writes synchronously.
          for (const name of touched) {
            const store = tx.objectStore(name);
            for (const raw of legacyRows[name]) {
              let rec = raw;
              if (name === "settings" && rec.key === "app") {
                if (!rec.value || typeof rec.value !== "object" || Array.isArray(rec.value)) {
                  throw new Error("إعدادات التطبيق المستوردة غير صالحة");
                }
                const merged = { ...rec.value };
                for (const field of PROTECTED_SECURITY_FIELDS) {
                  // Remove foreign security fields even when no local value exists.
                  delete merged[field];
                  if (local[field] !== undefined) merged[field] = local[field];
                }
                // L01-01b: The local device schema version must never be downgraded by an imported legacy file.
                merged.schemaVersion = SCHEMA_VERSION;
                rec = { ...rec, value: merged };
              }
              store.put(rec);
              count++;
            }
          }
        } catch (e) {
          try { tx.abort(); } catch (_) {}
          fail(e);
        }
      };

      settingsReq.onerror = () => { try { tx.abort(); } catch (_) {} fail(settingsReq.error || new Error("فشل قراءة إعدادات التطبيق")); };
      settingsReq.onsuccess = () => {
        localApp = settingsReq.result?.value;
        settingsDone = true;
        checkAndExecute();
      };

      prodsReq.onerror = () => { try { tx.abort(); } catch (_) {} fail(prodsReq.error || new Error("فشل قراءة جدول الأصناف")); };
      prodsReq.onsuccess = () => {
        liveTxProducts = prodsReq.result || [];
        prodsDone = true;
        checkAndExecute();
      };

      daysReq.onerror = () => { try { tx.abort(); } catch (_) {} fail(daysReq.error || new Error("فشل قراءة جدول الأيام")); };
      daysReq.onsuccess = () => {
        liveTxDays = daysReq.result || [];
        daysDone = true;
        checkAndExecute();
      };
    });
  }

  // Post-restore verification
  const postVerify = await runPostUpdateVerification(db);
  if (!postVerify.passed) {
    throw new Error(`COMMITTED_BUT_UNVERIFIED: تمت كتابة الاستعادة القديمة لكن فشل التحقق اللاحق: ${postVerify.error}`);
  }

  // Note: Recovery storage of prior device data is handled exclusively
  // by runSafetyBackupThenRestore before destructive restoration begins.

  if (isLegacyBackup) {
    await writeAuditLog("BACKUP_RESTORE", {
      fileSchema, isLegacy: true, recordsImported: imported,
      driverName: backup.driverName || "غير محدد",
    });
    return { imported, message: `تم استيراد نسخة قديمة (legacy → ${appSchema}) ✅ — ${imported.toLocaleString("ar-EG")} سجل` };
  } else {
    await writeAuditLog("BACKUP_RESTORE", {
      fileSchema, appSchema, isOlderSchema: true, recordsImported: imported,
      driverName: backup.driverName || "غير محدد",
    });
    return { imported, message: `تم الاستيراد مع ترقية الـ Schema (${fileSchema} → ${appSchema}) ⚠️ تحقق من البيانات — ${imported.toLocaleString("ar-EG")} سجل` };
  }
}



export { performRestore, isValidCalendarDate, initProductionCatalog, SEED_PRODUCTS };

export async function executeOpen(db, date, { onToast = () => {}, onDayOpened = () => {} } = {}) {
  let opening = false;
  const setOpening = (val) => { opening = val; };
  currentDB = db;

  async function open() {
    if (opening) return;
    setOpening(true);
    try {
      if (!isValidCalendarDate(date)) throw new Error("تاريخ غير صالح أو غير موجود تقويمياً");
      const db = await openDB();
      // D-01: All reads, concurrency checks, price updates, and carry-forward
      // writes are performed in one IndexedDB transaction. No async/await
      // occurs between opening the transaction and queuing its requests.
      await new Promise((resolve, reject) => {
        const tx = db.transaction(["days", "closingStock", "openingStock", "products", "settings", "auditLog", "dayPriceSnapshot"], "readwrite");
        let settled = false;
        const fail = error => { if (!settled) { settled = true; reject(error || new Error("New day transaction aborted")); } };
        tx.onabort = () => fail(tx.error || new Error("New day transaction aborted"));
        tx.onerror = () => {};
        tx.oncomplete = () => { if (!settled) { settled = true; resolve(); } };
        const daysReq = tx.objectStore("days").getAll();
        daysReq.onsuccess = () => {
          try {
            const days = daysReq.result;
            if (days.some(d => d.status === "open")) throw new Error("يوجد يوم مفتوح بالفعل");
            if (days.some(d => d.date === date)) throw new Error("يوجد سجل لهذا اليوم بالفعل");
            const closed = days.filter(d => d.status === "closed" && d.date < date).sort((a,b) => b.date.localeCompare(a.date));
            const closedDayId = closed.length ? closed[0].id : null;
            const stockReq = closedDayId
              ? tx.objectStore("closingStock").index("dayId").getAll(closedDayId)
              : null;
            const snapReq = closedDayId
              ? tx.objectStore("dayPriceSnapshot").index("dayId").getAll(closedDayId)
              : null;
            const settingsReq = tx.objectStore("settings").get("app");
            const productsReq = tx.objectStore("products").getAll();
            let stockReady = !stockReq, snapReady = !snapReq, settingsReady = false, productsReady = false;
            let stock = [], snapshots = [], settings, products;
            const commit = () => {
              if (!stockReady || !snapReady || !settingsReady || !productsReady) return;
              try {
                if (!settings || typeof settings !== "object") throw new Error("إعدادات الجهاز غير متاحة");
                const productByCode = new Map(products.map(p => [p.code, p]));
                const productById = new Map(products.map(p => [p.id, p]));
                const pending = settings.pendingPriceUpdates || [];
                if (!Array.isArray(pending)) throw new Error("قائمة تحديثات الأسعار غير صالحة");
                const due = pending.filter(u => !u.effectiveFromDate || u.effectiveFromDate <= date);
                const future = pending.filter(u => u.effectiveFromDate && u.effectiveFromDate > date);
                const updated = new Map();
                for (const u of due) {
                  const prod = productByCode.get(u.productCode);
                  if (!prod) {
                    throw new Error(`لا يمكن فتح اليوم: الصنف المطلوب لتحديث السعر المعلق (كود: "${u.productCode}") غير موجود في كتالوج المنتجات. يرجى مراجعة التحديثات المعلقة واعتمادها أو تسويتها بواسطة المدير أولاً.`);
                  }
                  const current = updated.get(prod.id) || prod;
                  const upc = u.newUnitsPerCarton ?? current.unitsPerCarton;
                  const price = u.newCartonPrice ?? current.cartonPrice;
                  if (!Number.isSafeInteger(upc) || upc <= 0 || !Number.isFinite(price) || price <= 0) {
                    throw new Error(`تحديث سعر غير صالح: ${u.productCode}`);
                  }
                  updated.set(prod.id, {...current, unitsPerCarton: upc, cartonPrice: price,
                    unitPrice: parseFloat((price / upc).toFixed(4)), updatedAt: Date.now()});
                }
                const inferredStockEntries = [];
                const unknownUpcStockEntries = [];
                const snapByProductId = new Map(snapshots.map(s => [s.productId, s]));
                const seen = new Set();
                for (const entry of stock) {
                  const originalProd = productById.get(entry.productId);
                  if (!originalProd || seen.has(entry.productId)) throw new Error("رصيد افتتاحي غير صالح أو مكرر");
                  seen.add(entry.productId);

                  // R31-04: Safe Integer & Non-Negative Validation
                  if (!Number.isSafeInteger(entry.totalUnits) || entry.totalUnits < 0) {
                    throw new Error(`كمية الوحدات الإجمالية غير صالحة للصنف: ${originalProd.name || entry.productId}`);
                  }
                  if (!Number.isSafeInteger(entry.cartons) || entry.cartons < 0) {
                    throw new Error(`عدد الكراتين غير صالح للصنف: ${originalProd.name || entry.productId}`);
                  }
                  if (!Number.isSafeInteger(entry.units) || entry.units < 0) {
                    throw new Error(`عدد الوحدات غير صالح للصنف: ${originalProd.name || entry.productId}`);
                  }

                  // R32-06 & REV3.2.1-A-01: Strict Historical Snapshot Resolution & Mathematical Inference
                  const snap = snapByProductId.get(entry.productId);
                  let historicalUpc;
                  let inferredUpc = false;
                  let historicalUpcUnknown = false;

                  if (snap !== undefined) {
                    // Snapshot exists: must be strictly valid
                    if (!Number.isSafeInteger(snap.unitsPerCarton) || snap.unitsPerCarton <= 0) {
                      throw new Error(`لقطة سعة الكرتونة التاريخية مشوهة لليوم المغلق للصنف: ${originalProd.name || entry.productId}`);
                    }
                    historicalUpc = snap.unitsPerCarton;
                  } else {
                    // No snapshot exists for this product on the closed day (e.g. legacy closed day):
                    if (entry.cartons > 0) {
                      // Mathematical inference: historicalUpc = (totalUnits - units) / cartons
                      if (entry.totalUnits < entry.units) {
                        throw new Error(`كمية ترحيل غير متسقة مع بيانات اليوم المغلق للصنف: ${originalProd.name || entry.productId}`);
                      }
                      const rawUpc = (entry.totalUnits - entry.units) / entry.cartons;
                      if (!Number.isSafeInteger(rawUpc) || rawUpc <= 0) {
                        throw new Error(`تعذر استنتاج سعة الكرتونة التاريخية لليوم المغلق للصنف: ${originalProd.name || entry.productId}`);
                      }
                      if (entry.units >= rawUpc) {
                        throw new Error(`تمثيل رصيد غير صالح للصنف ${originalProd.name || entry.productId}: عدد الوحدات المتبقية (${entry.units}) لا يمكن أن يكون مساوياً أو أكبر من سعة الكرتونة المستنتجة (${rawUpc})`);
                      }
                      historicalUpc = rawUpc;
                      inferredUpc = true;
                    } else {
                      // cartons === 0: All stock is in loose units (REV3.2.1-A-01: Historical UPC is unknown)
                      if (entry.totalUnits !== entry.units) {
                        throw new Error(`كمية ترحيل غير متسقة مع بيانات اليوم المغلق للصنف: ${originalProd.name || entry.productId}`);
                      }
                      historicalUpcUnknown = true;
                    }
                  }

                  if (!historicalUpcUnknown) {
                    // Remainder units must be strictly less than carton capacity
                    if (entry.units >= historicalUpc) {
                      throw new Error(`تمثيل رصيد غير صالح للصنف ${originalProd.name || entry.productId}: عدد الوحدات المتبقية (${entry.units}) لا يمكن أن يكون مساوياً أو أكبر من سعة الكرتونة (${historicalUpc})`);
                    }

                    // Safe integer overflow check before addition
                    if (entry.cartons > Math.floor(Number.MAX_SAFE_INTEGER / historicalUpc)) {
                      throw new Error(`تجاوز الحد الأقصى الآمن للحسابات (MAX_SAFE_INTEGER) للصنف: ${originalProd.name || entry.productId}`);
                    }
                    const computedTotal = entry.cartons * historicalUpc + entry.units;
                    if (!Number.isSafeInteger(computedTotal) || computedTotal !== entry.totalUnits) {
                      throw new Error(`كمية ترحيل غير متسقة مع بيانات اليوم المغلق للصنف: ${originalProd.name || entry.productId}`);
                    }
                  }

                  if (inferredUpc) {
                    inferredStockEntries.push({
                      productId: entry.productId,
                      productCode: originalProd.code,
                      inferredUpc: historicalUpc,
                      cartons: entry.cartons,
                      units: entry.units,
                      totalUnits: entry.totalUnits
                    });
                  } else if (historicalUpcUnknown) {
                    unknownUpcStockEntries.push({
                      productId: entry.productId,
                      productCode: originalProd.code,
                      cartons: 0,
                      units: entry.units,
                      totalUnits: entry.totalUnits
                    });
                  }
                }
                for (const prod of updated.values()) tx.objectStore("products").put(prod);
                if (inferredStockEntries.length > 0) {
                  tx.objectStore("auditLog").add({
                    timestamp: Date.now(),
                    action: "HISTORICAL_UPC_INFERRED_FROM_STOCK",
                    details: JSON.stringify({
                      dayDate: date,
                      closedDayId,
                      entries: inferredStockEntries
                    })
                  });
                }
                if (unknownUpcStockEntries.length > 0) {
                  tx.objectStore("auditLog").add({
                    timestamp: Date.now(),
                    action: "HISTORICAL_UPC_UNKNOWN",
                    details: JSON.stringify({
                      dayDate: date,
                      closedDayId,
                      entries: unknownUpcStockEntries
                    })
                  });
                }
                if (due.length) {
                  tx.objectStore("settings").put({key:"app", value:{...settings, pendingPriceUpdates:future}});
                  tx.objectStore("auditLog").add({timestamp:Date.now(), action:"PENDING_PRICE_UPDATE_APPLIED",
                    details:JSON.stringify({appliedCount:due.length, effectiveDate:date, codes:due.map(u=>u.productCode)})});
                }
                const addReq = tx.objectStore("days").add({date,status:"open",openedAt:Date.now()});
                addReq.onsuccess = () => {
                  try {
                    for (const entry of stock) {
                      // Preserve total physical units; normalize cartons for any new UPC.
                      const nextUpc = (updated.get(entry.productId) || productById.get(entry.productId)).unitsPerCarton;
                      const cartons = Math.floor(entry.totalUnits / nextUpc);
                      const units = entry.totalUnits % nextUpc;
                      tx.objectStore("openingStock").put({dayId:addReq.result,productId:entry.productId,
                        cartons,units,totalUnits:entry.totalUnits});
                    }
                  } catch (e) { try { tx.abort(); } catch (_) {} fail(e); }
                };
              } catch (e) { try { tx.abort(); } catch (_) {} fail(e); }
            };
            if (stockReq) stockReq.onsuccess = () => { stock = stockReq.result; stockReady = true; commit(); };
            if (snapReq) snapReq.onsuccess = () => { snapshots = snapReq.result; snapReady = true; commit(); };
            settingsReq.onsuccess = () => { settings = settingsReq.result?.value; settingsReady = true; commit(); };
            productsReq.onsuccess = () => { products = productsReq.result; productsReady = true; commit(); };
          } catch (e) { try { tx.abort(); } catch (_) {} fail(e); }
        };
      });
      onToast("تم فتح اليوم بنجاح 📅","success");
      onDayOpened();
    } catch(e) { onToast("خطأ: "+e.message,"error"); }
    finally { setOpening(false); }
  }

  

  await open();
}
